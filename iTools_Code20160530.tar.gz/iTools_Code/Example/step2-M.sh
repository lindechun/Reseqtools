#!/bin/sh
#$ -S /bin/sh
#Version1.0	hewm@genomics.org.cn	2012-05-18
echo Start Time : 
date
../bin/iTools Vartools SoapSnp 	-i	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapBychrSort/C01/Gm01.gz	-d	/share/project005/xuxun/heweiming/Soybean/reference_v2/Gm01.fa.gz	-o	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/C01/Gm01.glf	-F	1	-u	-L	76	-M	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/C01/Gm01.mat	
rm	/ifs5/PC_PA_AP/USER/heweiming/soy31/SoapSNP/C01/Gm01.mat	
echo End Time : 
date
