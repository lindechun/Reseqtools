
#ifndef MFile_Paste_H_
#define MFile_Paste_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../ALL/comm.h"
#include "../include/gzstream/gzstream.h"
#include "../ALL/DataClass.h"
using namespace std;
///////////////////
class InPARE {
	public:
		string InStr2;
		string InStr3;
		vector <string> File;
		vector <string> ROW;
		InPARE()
		{
		InStr2="";
		InStr3="";
	}
};

int  print_Paste()
{
	cout <<""
		"\n"
		"\tUsage: Paste -InList <in.list> -OutPut <out>\n"
		"\n"
		"\t\t-InList  <str>   Input file List for Paste\n"
		"\t\t-InFile  <str>   [Repeat]Input file for Paste\n"
		"\n"
		"\t\t-Row     <str>   [Repeat]InRow for default RowID[2]\n"
		"\t\t-OutPut  <str>   Output the Paste file[STDOUT]\n"
		"\t\t-help            Show this help\n" 
		"\t\tNotice:\n"
		"\t\tInList Format:[FilePath RowID] or [FilePath]\n"
		"\t\tRowID/Row can be multi: 1,4,6\n"
		"\n";
	return 1;
}

int parse_Paste_cmd(int argc, char **argv , InPARE * para_A4 )
{
	if (argc <=2 ) {print_Paste();return  0 ; }

	for(int i = 1; i < argc ; i++)
	{
	  if(argv[i][0] != '-')
	  {
		cerr << "command option error! please check." << endl;
		return 0;
	}
	  string flag=argv[i] ;
	  flag=replace_all(flag,"-","");

	  if (flag  ==  "OutPut")
	  {
		if(i + 1 == argc) {LogLackArg(flag);return 0;}
		i++;
		para_A4->InStr3=argv[i];
	}
	  else if (flag  ==  "InList")
	  {
		if(i + 1 == argc) {LogLackArg(flag); return 0;}
		i++;
		para_A4->InStr2=argv[i];
	}
	  else if (flag  == "InFile")
	  {
		if(i + 1 == argc) {LogLackArg(flag); return 0;}
		i++;
		string A=argv[i];
		(para_A4->File).push_back(A);
	}
	  else if (flag  == "Row")
	  {
		if(i + 1 == argc) {LogLackArg(flag); return 0;}
		i++;
		string A=argv[i];
		(para_A4->ROW).push_back(A);
	}
	  else if (flag  == "help")
	  {
		print_Paste(); return 0;
	}
	  else
	  {
		cerr << "UnKnow argument -"<<flag<<endl;
		return 0;
	}
  }
	if  ( ((para_A4->InStr2).empty() && (para_A4->File).empty()))
	{
	  cerr<< "lack argument for the must"<<endl ;
	  return 0;
  }
	return 1 ;
}



//////////////////

int MFile_Paste_main(int argc,char *argv[])
	//int main(int argc,char *argv[])
{
	InPARE * para_A4 = new InPARE ;
	if (parse_Paste_cmd( argc, argv ,  para_A4 )==0)
	{
	  delete para_A4 ;
	  return 1;
  }

	string DefaultRowID="2";
	if (!((para_A4->File).empty()))
	{
	  int FileSize=(para_A4->File).size();
	  int RowSize=(para_A4->ROW).size();
	  if (FileSize == RowSize)
	  {
		DefaultRowID=(para_A4->ROW)[RowSize-1];
	}
	  else if(RowSize<FileSize)
	  {
		if (RowSize>0)
		{
		DefaultRowID=(para_A4->ROW)[RowSize-1];
	}
		int a=FileSize-RowSize;
		for(int ii=0 ; ii<a ; ii++)
		{
		(para_A4->ROW).push_back(DefaultRowID) ;
	}
	}
	  else
	  {
		cerr<<"Warning:RowIn Repeat big than File In;Ignore Last"<<endl;
		cerr<<"Row Number: "<<RowSize<<"\tFile Number: "<<FileSize<<endl;
		int a=RowSize-FileSize;
		for(int ii=0 ; ii<a ; ii++)
		{
		(para_A4->ROW).pop_back();
	}
		int Rowtt=(para_A4->ROW).size();
		DefaultRowID=(para_A4->ROW)[Rowtt-1];
	}
  }
	if (!((para_A4->InStr2).empty()))
	{
	  igzstream IN_F1 ((para_A4->InStr2).c_str(),ifstream::in);
	  if (IN_F1.fail())
	  {
		cerr<<"Can't open file "<<(para_A4->InStr2)<<endl;
		return 0;
	}
	  while(!IN_F1.eof())
	  {
		string  line ;
		getline(IN_F1,line);
		if (line.length()<=0)  { continue  ; }
		vector<string> inf;
		split(line,inf," \t");
		if(inf.size()>1)
		{
		(para_A4->File).push_back(inf[0]);
		(para_A4->ROW).push_back(inf[1]);
	}
		else
		{
		(para_A4->File).push_back(inf[0]);
		(para_A4->ROW).push_back(DefaultRowID);
	}
	}
	  IN_F1.close();
  }

	int File_Acount=(para_A4->File).size();
	igzstream *MFile = new igzstream[File_Acount] ;
	vector <vector <int> >  VetRow (File_Acount) ;

	for (int i=0; i<File_Acount ; i++)
	{
	  MFile[i].open((para_A4->File)[i].c_str(),ifstream::in) ;
	  if  (!(MFile[i].good()))
	  {
		cerr<<(para_A4->File)[i]<<"\tcan't open"<<endl ;
	}
	  string line_tmp =(para_A4->ROW)[i];
	  vector <string> Temp;
	  vector <int> IntRow ;
	  split(line_tmp,Temp,",;");
	  int A=Temp.size();        
	  for (int kk=0 ; kk<A  ;kk++)
	  {
		int dd=atoi((Temp[kk]).c_str())-1;
		IntRow.push_back(dd);
	}
	  VetRow[i]=IntRow ;
  }


	if (!(para_A4->InStr3).empty())
	{
	  para_A4->InStr3=add_Asuffix(para_A4->InStr3);
	  ogzstream OUT ((para_A4->InStr3).c_str());
	  if(!OUT.good())
	  {
		cerr << "open OutFile error: "<<para_A4->InStr3<<endl;
		delete para_A4 ;
		return 1;
	}
	  while (!(MFile[0].eof()))
	  {
		string  line ;
		getline(MFile[0],line);
		if (line.length()<=0)
		{
		for ( int kp=1; kp<File_Acount ; kp++)
		{
		getline(MFile[kp],line);
	}
		continue  ; 
	}

		vector<string> inf;
		split(line,inf," \t");
		string print_line=inf[(VetRow[0])[0]];
		int lengthID1=(VetRow[0]).size();
		for (int ii=1 ; ii<lengthID1 ; ii++)
		{
		print_line=print_line+"\t"+inf[(VetRow[0])[ii]];
	}
		for ( int kp=1; kp<File_Acount ; kp++)
		{
		string utmp_line;
		getline(MFile[kp],utmp_line);
		vector<string> infTmp;
		split(utmp_line,infTmp," \t");
		int VecSize=(VetRow[kp]).size();
		for (int jj=0 ; jj<VecSize ; jj++)
		{
		print_line=print_line+"\t"+infTmp[(VetRow[kp])[jj]];
	}
	}
		OUT<<print_line<<endl;
	}    
  }
	else
	{
	  while (!(MFile[0].eof()))
	  {
		string  line ;
		getline(MFile[0],line);
		if (line.length()<=0)
		{
		for ( int kp=1; kp<File_Acount ; kp++)
		{
		getline(MFile[kp],line);
	}
		continue  ; 
	}

		vector<string> inf;
		split(line,inf," \t");
		string print_line=inf[(VetRow[0])[0]];
		int lengthID1=(VetRow[0]).size();
		for (int ii=1 ; ii<lengthID1 ; ii++)
		{
		print_line=print_line+"\t"+inf[(VetRow[0])[ii]];
	}
		for ( int kp=1; kp<File_Acount ; kp++)
		{
		string utmp_line;
		getline(MFile[kp],utmp_line);
		vector<string> infTmp;
		split(utmp_line,infTmp," \t");
		int VecSize=(VetRow[kp]).size();
		for (int jj=0 ; jj<VecSize ; jj++)
		{
		print_line=print_line+"\t"+infTmp[(VetRow[kp])[jj]];
	}
	}
		cout<<print_line<<endl;
	}
  }

	for (int i=0; i<File_Acount ; i++)
	{
	  MFile[i].close();
  }
	delete para_A4 ;
	delete [] MFile ;
	return 0 ;
}

#endif // MFile_Paste_H_

////////////////////////swimming in the sea & flying in the sky //////////////////

///////// swimming in the sky and flying in the sea ////////////
