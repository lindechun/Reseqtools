#ifndef VCF2Genotype_H_
#define VCF2Genotype_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>

using namespace std;
typedef long long  llong ;

int  VCF2GenotypeSNP_help()
{
	cout <<""
		"\n"
		"\tUsage: VCF2Genotype -InPut  <in.vcf>  -OutPut  <out.add_ref>\n"
		"\n"
		"\t\t-InPut   <str>   Input GATK VCF genotype File\n"
		"\t\t-OutPut  <str>   OutPut Genotype file\n"
		"\n"
		"\t\t-NoRef           Do not pring OUT Ref base[with ref base]\n"
		"\t\t-WithHeader      OutPut file add the header infomation\n"
		"\t\t-Warn            warning the Indel site for no chang\n"
		"\t\t-help            show this help\n"
		"\n";
	return 1;
}

int VCF2Genotype_help01(int argc, char **argv , In3str1v * paraFA04 )
{
	if (argc <=2 ) {VCF2GenotypeSNP_help();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag == "Warn")
		{
			paraFA04->TF=false;
		}
		else if (flag == "WithHeader")
		{
			paraFA04->InInt=1;
		}
		else if (flag == "NoRef")
		{
			paraFA04->TF2=false;
		}
		else if (flag == "help")
		{
			VCF2GenotypeSNP_help();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty()  )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(paraFA04->InStr2)=add_Asuffix(paraFA04->InStr2);
	return 1 ;
}


//int VCF2GenotypeSNP_main(int argc, char *argv[])
	int main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if ((VCF2Genotype_help01(argc, argv, paraFA04)==0))
	{
		delete paraFA04 ;
		return 0 ;
	}

	map <string ,char > SNP_Allele ;
	SNP_Allele["AC"]='M'; SNP_Allele["CA"]='M'; SNP_Allele["GT"]='K'; SNP_Allele["TG"]='K';
	SNP_Allele["CT"]='Y'; SNP_Allele["TC"]='Y'; SNP_Allele["AG"]='R'; SNP_Allele["GA"]='R';
	SNP_Allele["AT"]='W'; SNP_Allele["TA"]='W'; SNP_Allele["CG"]='S'; SNP_Allele["GC"]='S';
	SNP_Allele["AA"]='A'; SNP_Allele["TT"]='T'; SNP_Allele["CC"]='C'; SNP_Allele["GG"]='G';
	SNP_Allele["AN"]='A'; SNP_Allele["NA"]='A';
	SNP_Allele["CN"]='C'; SNP_Allele["NC"]='C';
	SNP_Allele["TN"]='T'; SNP_Allele["NT"]='T';
	SNP_Allele["GN"]='G'; SNP_Allele["NG"]='T';


	ogzstream OUT ((paraFA04->InStr2).c_str());

	if((!OUT.good()))
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr2)<<endl;
		delete  paraFA04 ; return  0;
	}

	if ((paraFA04->InInt)==1)
	{
		igzstream TTTS ((paraFA04->InStr1).c_str(),ifstream::in);
		if (TTTS.fail())
		{
			cerr << "open SNP File error: "<<(paraFA04->InStr1)<<endl;
			delete  paraFA04 ; return  0;
		}
		for ( int A=1 ; ( A<16888 && (!TTTS.eof()))  ; A++ )
		{
			string line ;
			getline(TTTS,line);
			if (line.length()<=0)  { continue  ; }
			else if (line[0] == '#')  
			{
				if  (line[1] == '#')
				{
					continue  ;
				}
				else
				{
					vector<string> inf ;
					split(line,inf," \t");

					int ASize=inf.size();
					if (paraFA04->TF2)
					{
						OUT<<inf[0]<<"\t"<<inf[1]<<"\t"<<inf[3];
						for (int jj=9 ; jj< ASize ;jj++)
						{
							OUT<<" "<<inf[jj];
						}
						OUT<<endl;
					}
					else
					{
						OUT<<inf[0]<<"\t"<<inf[1]<<"\t"<<inf[9];
						for (int jj=10 ; jj< ASize ;jj++)
						{
							OUT<<" "<<inf[jj];
						}
						OUT<<endl;
					}
				}
			}
			else
			{			    
				A=16899;
			}
		}
		TTTS.close();

	}

	igzstream SNP ((paraFA04->InStr1).c_str(),ifstream::in);
	if (SNP.fail())
	{
		cerr << "open SNP File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}

	if (paraFA04->TF)
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0 || line[0] == '#' )  { continue  ; }
			string GeneID  ;
			llong Site ;
			vector<string> inf ;
			split(line,inf," \t");
			int  Base_len=inf[3].length();
			vector<string> Alt ;
			split(inf[4],Alt,",");
			map <int,string> Num2Base ;
			Num2Base[0]=inf[3];
			for (int ii=0 ; ii<Alt.size() ;ii++)
			{
				if (Alt[ii].length()>Base_len)
				{
					Base_len=Alt[ii].length();
				}
				int j=ii+1;
				Num2Base[j]=Alt[ii]; 
			}
			if (Base_len>1)
			{
				continue ;
			}

			map <string,char> Num2Genotype ;
			map <int,string> ::iterator  key1 ; 
			map <int,string> ::iterator  key2 ; 
			for (key1=Num2Base.begin(); key1!=Num2Base.end() ; key1++)
			{
				for (key2=Num2Base.begin(); key2!=Num2Base.end() ; key2++)
				{
					string doub_A=(key1->second)+(key2->second);
					char Value=SNP_Allele[doub_A];
					string keyA=Int2Str(key1->first);
					string keyB=Int2Str(key2->first);
					string Final_key=keyA+"/"+keyB;
					Num2Genotype[Final_key]=Value;
					Final_key=keyB+"/"+keyA;
					Num2Genotype[Final_key]=Value;
					Final_key=keyA+"|"+keyB;
					Num2Genotype[Final_key]=Value;
					Final_key=keyB+"|"+keyA;
					Num2Genotype[Final_key]=Value;
				}
			}
			string temp="./." ;			Num2Genotype[temp]='-';
			temp=".|." ;			Num2Genotype[temp]='-';

			int A=inf.size();
			if (paraFA04->TF2)
			{
				OUT<<inf[0]<<"\t"<<inf[1]<<"\t"<<inf[3];
				for (int jj=9 ; jj< A ;jj++ )
				{
					vector<string> Btmp  ; 
					split(inf[jj], Btmp,":");
					char ctmp='N';
					ctmp=Num2Genotype[Btmp[0]];
					if (ctmp=='A'  ||  ctmp=='T'  ||  ctmp=='C'  || ctmp=='G'  )
					{
						vector<string> Depthtmp  ;
						split(Btmp[1], Depthtmp,":");
						int AA=atoi(Depthtmp[0].c_str())+atoi(Depthtmp[1].c_str());
						if (AA<5)
						{
							ctmp='-';
						}
					}

					OUT<<" "<<ctmp;
				}
				OUT<<endl;
			}
			else
			{
				vector<string> BtmpA  ;
				split(inf[9], BtmpA,":");
				char ctmpA='N';
				ctmpA=Num2Genotype[BtmpA[0]];
				OUT<<inf[0]<<"\t"<<inf[1]<<"\t"<<ctmpA;
				for (int jj=10 ; jj< A ;jj++ )
				{
					vector<string> Btmp  ; 
					split(inf[jj], Btmp,":");
					char ctmp='N';
					ctmp=Num2Genotype[Btmp[0]];
					//if (ctmp!='-'  && ctmp!='N' )
					if (ctmp=='A'  ||  ctmp=='T'  ||  ctmp=='C'  || ctmp=='G'  )
					{
						vector<string> Depthtmp  ;
						split(Btmp[1], Depthtmp,":");
						int AA=atoi(Depthtmp[0].c_str())+atoi(Depthtmp[1].c_str());
						if (AA<5)
						{
							ctmp='-';
						}
					}


					OUT<<" "<<ctmp;
				}
				OUT<<endl;
			}
		}
	}
	else
	{
		while(!SNP.eof())
		{
			string  line ;
			getline(SNP,line);
			if (line.length()<=0 || line[0] == '#' )  { continue  ; }
			string GeneID  ;
			llong Site ;
			vector<string> inf ;
			split(line,inf," \t");
			int  Base_len=inf[3].length();
			vector<string> Alt ;
			split(inf[4],Alt,",");
			map <int,string> Num2Base ;
			Num2Base[0]=inf[3];
			for (int ii=0 ; ii<Alt.size() ;ii++)
			{
				if (Alt[ii].length()>Base_len)
				{
					Base_len=Alt[ii].length();
				}
				int j=ii+1;
				Num2Base[j]=Alt[ii]; 
			}
			if (Base_len>1)
			{
				cerr<<"warning Indel site\t"<<inf[0]<<"\t"<<inf[1]<<endl;
				continue ;
			}

			map <string,char> Num2Genotype ;
			map <int,string> ::iterator  key1 ; 
			map <int,string> ::iterator  key2 ; 
			for (key1=Num2Base.begin(); key1!=Num2Base.end() ; key1++)
			{
				for (key2=Num2Base.begin(); key2!=Num2Base.end() ; key2++)
				{
					string doub_A=(key1->second)+(key2->second);
					char Value=SNP_Allele[doub_A];
					string keyA=Int2Str(key1->first);
					string keyB=Int2Str(key2->first);
					string Final_key=keyA+"/"+keyB;
					Num2Genotype[Final_key]=Value;
					Final_key=keyB+"/"+keyA;
					Num2Genotype[Final_key]=Value;
					Final_key=keyA+"|"+keyB;
					Num2Genotype[Final_key]=Value;
					Final_key=keyB+"|"+keyA;
					Num2Genotype[Final_key]=Value;
				}
			}
			string temp="./." ;			Num2Genotype[temp]='-';
			temp=".|." ;			Num2Genotype[temp]='-';

			int A=inf.size();
			if (paraFA04->TF2)
			{
				OUT<<inf[0]<<"\t"<<inf[1]<<"\t"<<inf[3];
				for (int jj=9 ; jj< A ;jj++ )
				{
					vector<string> Btmp  ; 
					split(inf[jj], Btmp,":");
					char ctmp='N';
					ctmp=Num2Genotype[Btmp[0]];

					//if (ctmp!='-'  && ctmp!='N' )
					if (ctmp=='A'  ||  ctmp=='T'  ||  ctmp=='C'  || ctmp=='G'  )
					{
						vector<string> Depthtmp  ;
						split(Btmp[1], Depthtmp,":");
						int AA=atoi(Depthtmp[0].c_str())+atoi(Depthtmp[1].c_str());
						if (AA<5)
						{
							ctmp='-';
						}
					}

					OUT<<" "<<ctmp;
				}
				OUT<<endl;
			}
			else
			{
				vector<string> BtmpA  ;
				split(inf[9], BtmpA,":");
				char ctmpA='N';
				ctmpA=Num2Genotype[BtmpA[0]];
				OUT<<inf[0]<<"\t"<<inf[1]<<"\t"<<ctmpA;
				for (int jj=10 ; jj< A ;jj++ )
				{
					vector<string> Btmp  ; 
					split(inf[jj], Btmp,":");
					char ctmp='N';
					ctmp=Num2Genotype[Btmp[0]];

					//if (ctmp!='-'  && ctmp!='N' )
					if (ctmp=='A'  ||  ctmp=='T'  ||  ctmp=='C'  || ctmp=='G'  )
					{
						vector<string> Depthtmp  ;
						split(Btmp[1], Depthtmp,":");
						int AA=atoi(Depthtmp[0].c_str())+atoi(Depthtmp[1].c_str());
						if (AA<5)
						{
							ctmp='-';
						}
					}

					OUT<<" "<<ctmp;
				}
				OUT<<endl;
			}
		}
	}
	SNP.close();
	OUT.close();
	delete paraFA04 ;
	return 0;
}
#endif // VCF2Genotype_H_  //
///////// swimming in the sky and flying in the sea ////////////

