/*
 * DataClass.h
 *
 *  Created on: 2011-11-21
 *      Author: hewm@genomics.org.cn
 */

#ifndef ViewSoap_H_
#define ViewSoap_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cmath>
#include <iomanip>
#include <cassert>
#include <cstdlib>
#include <assert.h>
#include <ctype.h>
#include "../../ALL/DataClass.h"
#include <curses.h>
#include "../../include/gzstream/gzstream.h"
#include "../../include/zlib/zlib.h"
#include "../../ALL/comm.h"
#include "../../Xam/Alg_View.h"
//string, cctype,algorithm

using namespace std;
//#define Max_Input_Line 1024286
/////////////////// q_seq  for site ////////
int Alg_View_main(int argc, char *argv[]) ;

int  print_Ausage_SV13()
{
	cout <<""
		"\n"
		"\tUsage: view  -InPut <in.soap> -Ref <Ref.fa>\n"
		"\n"
		"\t\t-InPut     <str>   InPut SortSoap File\n"
		"\n"
		"\t\t-Ref       <str>   InPut Ref Seq fa\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Viewcmd(int argc, char **argv,In3str1v * para_SV13)
{
	if (argc <=2 ) {print_Ausage_SV13();return 0 ;}


	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag == "InPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_SV13->InStr1=argv[i];
		}
		else if (flag == "Ref")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_SV13->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_Ausage_SV13();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_SV13->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


//int Alg_View_main(int argc, char *argv[])
//int main(int argc, char *argv[])
int Soap_View_main(int argc, char *argv[])
{
	In3str1v * para_SV13 = new In3str1v;
	if (parse_Viewcmd(argc, argv, para_SV13 )==0)
	{
		delete para_SV13 ;
		return 0;
	}
	
	char * A = const_cast<char*>((para_SV13->InStr1).c_str());
	if ((para_SV13->InStr2).empty())
	{
		char * ssTmp[3]={"view", "-InSoap", A   };
		Alg_View_main(3 , ssTmp ) ;
	}
	else
	{
		char * B = const_cast<char*>((para_SV13->InStr2).c_str());
		char * ssTmp[5]={"view", "-InSoap", A ,"-Ref" ,B  };
		Alg_View_main( 5 , ssTmp ) ;
	}

	delete para_SV13 ;
	return 0;
}



#endif /* ViewSoap_H_ */

