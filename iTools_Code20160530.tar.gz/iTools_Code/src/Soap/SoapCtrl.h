/*
 * SoapCtrl.h
 *
 *  Created on: 2011-11-21
 *      Author: hewm@genomics.org.cn
 */

#ifndef SoapCtrl_H_
#define SoapCtrl_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cmath>
#include <iomanip>
#include <cassert>
#include <cstdlib>
#include ../include/gzstream/gzstream.h>

using namespace std;

class SoapCtrl
{
	private:
		string soap_Ain_Apath ; // the soap in file's path.
		igzstream  FileHand ; //  soap file handler, use as reading.
		int is_Aopen;
	public:
		SoapCtrl();
		SoapCtrl( string filepath );
		~SoapCtrl(void);
		bool open(const char *path, const char *mode);         
		void close();
		int readline(string &line);
		bool isOpened();
};

SoapCtrl::SoapCtrl()
{
	soap_Ain_Apath="";
	is_Aopen=0 ;
}

bool SoapCtrl::open(const char *path, const char *mode)
{
	soap_Ain_Apath=path;
	if ( is_Aopen ==1 )
	{
		FileHand.close();
		FileHand.clear();
	}
	FileHand.open(path,ifstream::in);
	if (!FileHand.good())
	{
		cerr<<"File open Fail\t"<<path<<endl;
		return 1;
	}
	is_Aopen = 1;
	return true ;
}

SoapCtrl::SoapCtrl(string  filepath )
{
	soap_Ain_Apath=filepath;
	FileHand.open(filepath.c_str(),ifstream::in);
	if (!FileHand.good())
	{
		cerr<<"File open Fail\t"<<filepath<<endl;
		return 1;
	}
	is_Aopen = 1;
}


bool SoapCtrl::isOpened()
{
	return (is_Aopen);
}

int SoapCtrl::readline (string & line)
{
	int ReadSucced=1;
	getline(FileHand,line);
	if (line.length()<=0) 
	{
		ReadSucced=0;
		if (FileHand.eof())
		{
			FileHand.close();
			FileHand.clear();
			is_Aopen=0;
		}
	}
	return ReadSucced ;
}

void SoapCtrl::close()
{
	soap_Ain_Apath="";
	if (is_Aopen==1 )
	{
		FileHand.close();
		FileHand.clear();
	}
	is_Aopen=0;
}

SoapCtrl::~SoapCtrl(void)
{
	soap_Ain_Apath="";
	if (is_Aopen==1 )
	{
		FileHand.close();
		FileHand.clear();
	}
	is_Aopen=0;
};

////////swimming in the sky and flying in the sea *///////////

#endif /* SoapCtrl_H_  */


//////////////// swimming in the sky and flying in the sea ////////////////
