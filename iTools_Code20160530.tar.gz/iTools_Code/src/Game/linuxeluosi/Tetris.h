#ifndef BERT_TETRIS_H
#define BERT_TETRIS_H

#include <bitset>
#include <aio.h>

#include "Thread.h"

// 一个用printf做的linux俄罗斯方块

class Tetris : public Thread
{
	public:
		Tetris();    
		int  IF ;
		~Tetris();
	private:
		enum BOARD_T
		{
			TYPE_BLANK = 0, //空白
			TYPE_BLOCK,	    //阻挡
			TYPE_BORDER,	//边界
			TYPE_MAX = 3,
		};

		// 游戏背景,尺寸
		static const int HEIGHT = 26;
		static const int WIDTH  = 16;
		BOARD_T m_board[HEIGHT][WIDTH] ;

		// 当前活动方块的坐标
		volatile int m_curx, m_cury;

		// 当前活动方块的样式及翻转形状
		int m_curstyle;
		int m_curpos;

		// 当前活动方块的颜色
		int m_curcolor ;

		// 玩家当前得分和等级
		unsigned int   m_score;
		unsigned short m_level;
		static const unsigned short MAXLEVEL = 9;

		// 一个方块的定义
		typedef std::bitset<16> Block;

		// 方块的样式种类
		static const unsigned short STYLE_MAX = 7;

		// 当前活动方块与下一个方块
		Block m_activeBlock, m_nextBlock;

		// 现在是否有活动方块?
		volatile bool m_active;

		// 游戏暂停？
		volatile bool m_pause;

		// 方块样式预定义
		static const unsigned short _styles_[STYLE_MAX][4] ;
		static Block styles[STYLE_MAX][4];

		//  初始化方块样式
		void InitStyles();

		//  显示分数
		void DrawScore();

		//  显示等级
		void DrawLevel();

		//  显示下一个方块
		void DrawNext();

		// 异步IO,完成显示和响应键盘的功能
		struct aiocb m_cb;
		static const int SIZE = 16;
		char m_inputBuf[SIZE];
		friend int AioHandler(int sig, siginfo_t *info, void * context);

		// 初始化背景数据
		void InitBackground();

		// 绘制游戏画面
		void Paint(int srcx = 0, int dstx = HEIGHT);

		// 判断方块是否与阻挡或边界冲突
		bool IsCollide();
		bool overgame();
		// 消行，并返回削去的行数(0-4)
		int RemoveLines();

		// 判断line行是否为空
		bool IsEmptyLine(int line);

		// 根据消行，返回应得分数
		static const unsigned short bonus[5];

		// 达到相应等级所需要的分数;10-levels
		static const unsigned int levels[10];

		//  根据得分，计算等级
		static unsigned short GetLevel(unsigned int score);

		// 线程函数，游戏逻辑
		virtual void Run();
};

#endif
