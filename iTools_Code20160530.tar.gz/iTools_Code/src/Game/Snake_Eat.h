#ifndef  Snake_Eat_H_
#define  Snake_Eat_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include "../include/gzstream/gzstream.h"
#include "../include/gzstream/gzstream.h"
#include "../ALL/comm.h"
#include "../ALL/Thread.h"
#include <ncurses.h>
#include <ctime>

//#define MAX_OPr  255 ;
//#include <sys/select.h>
//#include <stdio.h>
//#include <conio.h>
typedef long long llong ;
using namespace std;
///////////////////

class Snake : public Thread
{
	public:
		int mrow ;
		int mcol ;
		vector <char> operations ;
		//        char operations[MAX_OPr];
		//        int Un_oper; 
		int **Arry ;
		int **ArryX ;
		int **ArryY ;
		//        WINDOW *whelp ;
		Thread *th1;
		Thread *th2;
		int score ;
		bool m_pause ;
		int P_A, P_S ,P_D, P_W;        
		int H_X, H_Y ,T_X, T_Y;
		int RunX ,RunY ;
		bool Game_Over ;

	public:
		unsigned int sleep_time ;
		int tv_Init();
		bool tv_Draw();
		void get_operations();
		int tv_Destroy();
		int rand_next() ;
		bool Eat_one();
		int run_operations();
		virtual void run();
		int tv_Run();
		//   int run () ; 
};

int Snake::rand_next()
{
	while(true)
	{
		int X=(rand()%P_D);
		int Y=(rand()%P_S);
		if (X>P_A && Y>P_W && Arry[X][Y]==0 )
		{
			Arry[X][Y]=1;
			score++;
			return 1;
		}
	}
	return 1 ;
}

bool Snake::Eat_one()
{
	int tmpT_X=T_X ;
	int tmpT_Y=T_Y ;
	Arry[tmpT_X][tmpT_Y]=0;
	T_X+=ArryX[tmpT_X][tmpT_Y];
	T_Y+=ArryY[tmpT_X][tmpT_Y];
	ArryX[tmpT_X][tmpT_Y]=0;
	ArryY[tmpT_X][tmpT_Y]=0;

	ArryX[H_X][H_Y]=RunX;
	ArryY[H_X][H_Y]=RunY;

	H_X+=RunX; H_Y+=RunY;
	Arry[H_X][H_Y]++;
	if (Arry[H_X][H_Y]==2)
	{
		int tmp1=H_X+RunX ;
		int tmp2=H_Y+RunY ;    
		if (Arry[tmp1][tmp2]==0  &&   ArryX[H_X][H_Y]==0  &&  ArryY[H_X][H_Y]==0 )
		{
			Arry[H_X][H_Y]=1;
			ArryX[H_X][H_Y]=RunX;
			ArryY[H_X][H_Y]=RunY;
			Arry[tmp1][tmp2]=1;
			H_X=tmp1 ;
			H_Y=tmp2 ;
			rand_next();
			return true ;    
		}
		else
		{
			return false;
		}
	}
	return false;
}

void Snake::get_operations()
{
	while(true)
	{
		if (Game_Over) { return ;}
		int c = getch();
		switch (c)
		{
			case 'h':
			case 'H':
			case '?': operations.push_back('h') ; break;
			case '\033':
			case 'Q':
			case 'q': operations.push_back('q') ; break;
			case KEY_LEFT:
			case 'a': operations.push_back('l') ; break;
			case KEY_RIGHT:
			case 'd': operations.push_back('r') ; break;
			case KEY_UP:
			case 'w': operations.push_back('u') ; break;
			case KEY_DOWN:
			case 's': operations.push_back('d') ; break;
			case 'l': 
			case 'L': sleep_time=sleep_time+20; break;
			case 'f': 
			case 'F': if(sleep_time>30) {sleep_time=sleep_time-30;} else {sleep_time=sleep_time-5;}  break;
			case 'p': 
			case 'P': m_pause=(!m_pause); break;
			case KEY_RESIZE: getmaxyx(stdscr, mrow, mcol); break;
			default: continue;
		}
	}
}

bool Snake::tv_Draw()
{
	clear(); 
	int attr=0;
	attr |= COLOR_PAIR(8); attron(attr);
	mvaddstr(1,(mcol/2)-20,"Welcome come,Eat Snake Game");
	int HelpPosi=mcol-17 ;
	mvaddstr(1,HelpPosi,"Love hewm");
	mvaddstr(8,HelpPosi,"Anykey : Begin");
	mvaddstr(10,HelpPosi,"Arrows : move");
	mvaddstr(12,HelpPosi,"a,s,w,d: move");
	mvaddstr(14,HelpPosi,"p   : Stop");
	mvaddstr(16,HelpPosi,"f   : Fast");
	mvaddstr(18,HelpPosi,"l   : slow");    
	mvaddstr(20,HelpPosi,"q   : leave");
	//P_D=mcol-10;
	attroff(attr);
	attr=0;
	int check=0;
	attr |= COLOR_PAIR(3);
	attron(attr);

	for(int ii=0 ; ii< mcol ; ii++)
	{
		for ( int jj=0 ; jj< mrow ; jj++ )
		{
			if ( Arry[ii][jj]>0 )
			{
				mvaddch(jj,ii,'*');
				check++ ;
			}
			else if ( Arry[ii][jj]<0 )
			{
				mvaddch(jj,ii,'+') ;
			}
		}
	}
	int time=(sleep_time)/10;
	string Score="Score  :"+Int2Str(score);
	mvaddstr(26,HelpPosi,Score.c_str());
	Score="speed(time):"+Int2Str(time);
	mvaddstr(28,HelpPosi,Score.c_str());
	attroff(attr);
	refresh();
	if ( check==score )
	{
		return true;   
	}
	else
	{
		return false ;
	}
}

int Snake::tv_Init()
{
	initscr();keypad(stdscr, TRUE);
	clear();
	noecho();cbreak();
	mrow = 24; mcol = 80;
	//    Un_oper=0;
	sleep_time =150 ;
	m_pause=false ;
	Game_Over=false ;
	getmaxyx(stdscr, mrow, mcol) ;
	//whelp = newwin(15, 40, 5, 5);
	start_color();
	init_pair(0, COLOR_CYAN, COLOR_GREEN);
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(2, COLOR_GREEN, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_WHITE, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(6, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_RED, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);

	P_A=1;        P_S=mrow-1 ;
	P_D=mcol-18;  P_W=2 ;

	Arry  = new int *[mcol] ;
	Arry[0] = new int[mcol*mrow] ;

	ArryX  = new int *[mcol] ;
	ArryX[0] = new int[mcol*mrow] ;

	ArryY  = new int *[mcol] ;
	ArryY[0] = new int[mcol*mrow] ;

	for(int i = 1; i < mcol; i++)
	{
		Arry[i] = Arry[i-1]+mrow;
		ArryX[i] = ArryX[i-1]+mrow;
		ArryY[i] = ArryY[i-1]+mrow;
	}


	for (int ii=0 ; ii< mcol ; ii++)
	{
		for (int jj=0 ; jj< mrow ; jj++)
		{
			Arry[ii][jj]=0;
			ArryX[ii][jj]=0;
			ArryY[ii][jj]=0;
		}
	}

	srand((unsigned)time(NULL));

	for(int ii=0 ; ii< mrow ; ii++)
	{        
		Arry[P_A][ii]=-1;
		Arry[P_D][ii]=-1;
	}

	for(int ii=0 ; ii < mcol ; ii++)
	{
		Arry[ii][P_W]=-1;
		Arry[ii][P_S]=-1;
	}

	RunX=0 ;RunY=-1;
	//    cerr<<"hewm"<<mrow<<"\t"<<mcol<<endl;
	H_X=(P_A+P_D)/2;
	H_Y=(P_W+P_S)/2;
	Arry[H_X][H_Y]=1;

	T_X=H_X;  
	T_Y=H_Y-1;
	ArryY[T_X][T_Y]=1;
	Arry[T_X][T_Y]=1;

	score=2;
	rand_next();
	tv_Draw();
	getch();
	return 1 ;
}

int Snake:: tv_Destroy()
{
	delete [] Arry[0] ;
	delete [] Arry ;
	delete [] ArryX[0] ;
	delete [] ArryX ;
	delete [] ArryY[0] ;
	delete [] ArryY ;
	//    delwin(whelp);
	endwin();
	delete th1;
	delete th2;
	return 1;
}

int Snake::run_operations()
{

	while ( tv_Draw() )
	{
		usleep(sleep_time* 1000U );
		while(!operations.empty())
		{

			char c=operations[0];
			operations.erase(operations.begin());

			switch (c)
			{
				case 'h': ; break;
				case 'q':  goto End_Flag ; break;
				case 'l':if(RunX!=1 ){RunX=-1,RunY=0;} break;
				case 'r':if(RunX!=-1 ) {RunX=1; RunY=0;}  break;
				case 'u': if(RunY!=1) {RunX=0; RunY=-1;} break;
				case 'd': if(RunY!=-1) {RunX=0; RunY=1;} break;
				default: continue;
			}
			while ( m_pause )
			{
				usleep(sleep_time*1000U);
				continue ;
			}
		}
		Eat_one();
		while ( m_pause )
		{
			usleep(sleep_time*1000U);
			continue ;
		}

	}
End_Flag :
	int B=0;
	B |= COLOR_PAIR(5); attron(B);
	mvaddstr(mrow/2,mcol/2,"Eat Snake Game Over");
	mvaddstr(mrow/2+2,mcol/2,"Enter 'yy' : Repeat");
	mvaddstr(mrow/2+4,mcol/2,"Enter 'nn' : Leave");
	mvaddstr(mrow/2+6,mcol/2,"Welcome Again");
	mvaddstr(mrow/2+8,mcol/2,"hewm@genomics.org.cn");
	attroff(B);
	refresh();
	Game_Over=true ;
	return 0 ;
}

int  Snake::tv_Run()
{
	th1 = new Thread(this);
	th2 = new Thread(this);
	start();
	th1->start();
	th2->start();
	th1->join();
	th2->join();
	return 1;
}

void Snake::run()
{
	if (Thread::isEquals(th1))
	{
		get_operations();
	}
	else if (Thread::isEquals(th2))
	{
		if(run_operations()==0)
		{
			return  ;
		}
	}
	else
	{
		return ;
	}
}

int Game_Snake_main(int argc, char** argv)
{
	bool Game_Repeat=true ;

	while(true)
	{
		Snake  game ;
		game.tv_Init() ;
		game.tv_Run();
		while(true)
		{
			int c=getch();
			if (c=='Y' || c=='y' || c==32)
			{
				Game_Repeat=false ;
				break ;
			}
			else if( c=='n' || c=='N' || c=='q' || c=='Q')
			{
				Game_Repeat=true ;
				break ;
			}
		}
		game.tv_Destroy();
		if (Game_Repeat)
		{
			return 1 ;
		}
	}
	return 0;
}

////////////////////////swimming in the sea & flying in the sky //////////////////

#endif // Snake_Eat_H_
//
