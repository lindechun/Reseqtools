#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "Snake_Eat.h"
#include "DropBar.h"
#include "LiangLianKan.h"
#include "FindMine.h"
#include "PuzzleGame.h"
#include "Cal24.h"
#include "ELS.h"
#include "Sudoku.h"
#include "Sudoku99.h"


using namespace std;

int Game_Snake_main(int argc, char** argv) ;
int Game_DropBar_main(int argc, char** argv) ;
int Game_LLK_main(int argc, char** argv) ;
int Game_Mine_main(int argc, char** argv) ;
int Game_Puzzle_main(int argc, char** argv) ;
int Game_Cal24_main (int argc, char *argv[]) ;
int Game_Sudoku_main(int argc, char** argv) ;
int Game_SudokuV2_main(int argc, char** argv) ;
int Game_ELS_main(int argc, char** argv) ;

static int  Game_usage ()
{
	cerr<<""
		"\n"
		"\tGameTools Usage:\n\n"
		"\t\tSnake       Snake Greed Eat Game\n"
		"\t\tDropRock    Flee Drop Rock Game\n"
		"\t\tLLK         Lian Lian Kan Game\n"
		"\t\tPuzzle      Order digit in Puzzle\n"
		"\t\tFindMine    Mine sweep Game\n"
		"\t\tTetris      Tetris Russia game\n"
		"\t\tCal24       4 Num compute 24 Game\n"
		"\t\tSudoku1     Sudoku(SumNum)(n^2) Game\n"
		"\t\tSudoku2     Sudoku(SumNum)(1-9) Game\n"
		"\n"        
		"\t\tHelp        Show this help\n"
		"\n";
	return 1;
}

int Game_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return Game_usage(); }
	else if (strcmp(argv[1], "Snake") == 0) { return Game_Snake_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "DropRock") == 0) { return Game_DropBar_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "LLK") == 0) { return Game_LLK_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "FindMine") == 0) { return Game_Mine_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Puzzle") == 0) { return Game_Puzzle_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Cal24") == 0) { return Game_Cal24_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Sudoku") == 0) { return Game_SudokuV2_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Sudoku1") == 0) { return Game_Sudoku_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Sudoku2") == 0) { return Game_SudokuV2_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Tetris") == 0) { return Game_ELS_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0) { Game_usage(); }
	else
	{
		cerr<<"GameTools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;
}

