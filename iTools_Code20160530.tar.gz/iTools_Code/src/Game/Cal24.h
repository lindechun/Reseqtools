
#ifndef  Cal24_H_
#define  Cal24_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include <stdio.h>
#include <ncurses.h>
#include <ctime>
#include "../ALL/comm.h"
#include "Draw_comm.h"

#include <boost/spirit/core.hpp>
#include <iostream>
#include <string>
#include <stack>

////////////////////////////////////////////////////////////////////////////
using namespace std;
using namespace boost::spirit;
////////////////////////////////////////////////////////////////////////////
//
//  Semantic actions
//
////////////////////////////////////////////////////////////////////////////
namespace
{
	stack<double> calc_stack;

	struct do_add
	{
		double operator () (double lhs, double rhs) const
		{
			return lhs + rhs;
		}
	};
	struct do_substract
	{
		double operator () (double lhs, double rhs) const
		{
			return lhs - rhs;
		}
	};
	struct do_multiply
	{
		double operator () (double lhs, double rhs) const
		{
			return lhs * rhs;
		}
	};
	struct do_divide
	{
		double operator () (double lhs, double rhs) const
		{
			return lhs / rhs;
		}
	};
	template <typename op>
		struct do_calc
		{
			void operator () (const char *, const char *) const
			{
				double result = calc_stack.top();
				calc_stack.pop();
				result = op()(calc_stack.top(), result);
				calc_stack.pop();
				calc_stack.push(result);
			}
		};
	void push_real(double d)
	{
		calc_stack.push(d);
	}
	void do_neg(char const*, char const*)  
	{
		cout << "NEGATE\n";
		double result = calc_stack.top();
		calc_stack.pop();
		calc_stack.push(-result);
	}
	double show_result()     
	{
		return calc_stack.top();
	}
}

////////////////////////////////////////////////////////////////////////////
//
//  Our calculator grammar
//
////////////////////////////////////////////////////////////////////////////
struct calculator : public grammar<calculator>
{
	template <typename ScannerT>
		struct definition
		{
			definition(calculator const& /*self*/)
			{
				expression
					=   term
					>> *(   ('+' >> term[do_calc<do_add>()])
							|   ('-' >> term[do_calc<do_substract>()])
						)
					;

				term
					=   factor
					>> *(   ('*' >> factor[do_calc<do_multiply>()])
							|   ('/' >> factor[do_calc<do_divide>()])
						)
					;

				factor
					=   real_p[&push_real]
					|   '(' >> expression >> ')'
					|   ('-' >> factor[&do_neg])
					|   ('+' >> factor)
					;
			}

			rule<ScannerT> expression, term, factor;

			rule<ScannerT> const&
				start() const { return expression; }
		};
};

void begin_print(void) 
{ 
	int          i; 

	//    bkgd(COLOR_PAIR()); 
	box(stdscr, 0, 0); 
	Box(stdscr, 0, 0,23,80,COLOR_PAIR(7)); 
	Box(stdscr, 6, 3, 12, 35, COLOR_PAIR(1)); 
	int attr = COLOR_PAIR(7); attron(attr);

	for (i = 1; i < 4; ++i) 
	{
		mvvline(7, 4-1+i*8, ACS_VLINE, 5); 
	}

	mvvline(1, 39, ACS_VLINE, 22);

	attroff(attr);

	for (i = 0; i < 4; ++i) { 
		Box(stdscr, 7, 4+1+i*8, 11, 4+1+i*8+4, COLOR_PAIR(8)); 
		fill_rectangle(stdscr, 8, 4+1+1+i*8, 10, 4+i*8+4, ' ' | COLOR_PAIR(12)); 
	}

	attr = COLOR_PAIR(5); attron(attr);
	mvprintw(3, 12, "Welcome to 24!"); 
	mvprintw(14, 4, "Your answer: ('q' to end)"); 
	mvhline(17, 5, ACS_HLINE, 28); 
	mvaddstr(22, 3, "R:"); 
	mvaddstr(22, 10, "S:"); 
	mvaddstr(22, 17, "RATE:"); 
	mvaddch(22, 28, '%'); 
	mvaddstr(21, 30, "Ver 1.0"); 
	Box(stdscr, 2, 42, 21, 75, COLOR_PAIR(1)); 
	mvaddstr(5, 43, "Notes:"); 
	mvaddstr(8, 43,    "1. Direct Enter try next round."); 
	mvaddstr(10, 43, "2. A stands 1."); 
	mvaddstr(12, 43, "3. J Q K stand for 11,12,13"); 
	//   mvaddstr(14, 43, "4. Press 'A' to auto run."); 
	mvaddstr(14, 43, "5. Press 'q' to quit the game."); 
	mvaddstr(16, 43, "6. Time only 1 mins For each"); 
	mvaddstr(18, 43, "7. hewm@genomics.org.cn"); 
	mvaddstr(19, 4, "Info:"); 
	mvaddstr(20, 51, "Have a good time!"); 
	mvaddstr(16,4, "InPut :"); 

	attroff(attr);
	return; 
} 

///////////////////

int Game_Cal24_main (int argc, char *argv[])
{
	initscr();
	//noecho();
	cbreak();
	raw();
	curs_set(1);
	keypad(stdscr, TRUE);
	start_color();
	init_pair(1, COLOR_BLUE, COLOR_BLACK);
	init_pair(6, COLOR_WHITE, COLOR_BLACK);
	init_pair(3, COLOR_YELLOW, COLOR_BLACK);
	init_pair(4, COLOR_RED, COLOR_BLACK);
	init_pair(5, COLOR_GREEN, COLOR_BLACK);
	init_pair(2, COLOR_CYAN, COLOR_BLACK);
	init_pair(7, COLOR_YELLOW, COLOR_BLACK);
	init_pair(8, COLOR_GREEN, COLOR_BLACK);
	init_pair(9, COLOR_BLUE, COLOR_BLACK);
	init_pair(10, COLOR_RED, COLOR_CYAN);
	init_pair(11, COLOR_RED, COLOR_GREEN);
	init_pair(12, COLOR_RED, COLOR_BLUE);
	init_pair(13, COLOR_CYAN, COLOR_GREEN);
	int  mrow=82 ;
	int  mcol=42 ;
	getmaxyx(stdscr,mrow, mcol);
	begin_print(); 
	srand(time(NULL)); 
	int Sum_count=0;
	int right_count=0 ;
	calculator calc;    //  Our parser
	while (true)
	{
		int attr = COLOR_PAIR(12); attron(attr);
		char str[256];
		vector <string> For ;
		for (int i = 0; i < 4; ++i) 
		{ 
			int P=rand()%13+1;
			if (P>9)
			{
				P=rand()%13+1;
				if (P>9)
				{
					int B=rand()%4;
					if (B!=1)
					{
						P=rand()%13+1;
					}
				}
			}

			string tmp=Int2Str(P);
			For.push_back(tmp);
			if (P==1)
			{
				tmp="A";
			}
			else if (P==11)
			{
				tmp="J";
			}
			else if (P==12)
			{
				tmp="Q";
			}
			else if (P==13)
			{
				tmp="K";
			}
			if (tmp!="10")
			{
				tmp+=" ";
			}
			mvaddstr(9, 4+i*8+3,tmp.c_str());        
		}
		attroff(attr);
		refresh();
		attr = COLOR_PAIR(2); attron(attr);

		time_t start_time = time(NULL);
		Sum_count++;
		mvgetstr(16,11, str); 
		string run=str ;
		if (run.empty())
		{
			continue ;
		}
		if ( run[0] == 'q' || run[0] == 'Q')
		{
			break;
		}

		run=replace_all(run,"A","1");
		run=replace_all(run,"J","11");
		run=replace_all(run,"Q","12");
		run=replace_all(run,"K","13");
		bool USE=false ;
		for (int ii=0 ; ii<4 ; ii++ )
		{
			if (run.find(For[ii])== string::npos)
			{
				USE=true ;
			}
		}

		//mvprintw(3, 12, run.c_str() );

		time_t end_time = time(NULL);

		parse_info<> info = parse(run.c_str(), calc, space_p);

		int usetime=end_time-start_time ;

		int out=23;
		if (info.full)
		{
			out= int(show_result()) ;
		}
		string Result="Result : "+Int2Str(out) ;
		string right_or_wrong;
		if (USE)
		{
			right_or_wrong="NoUse above Num ";
		}
		else if (out==24  &&  usetime <60)
		{
			right_or_wrong="Well done...    ";
			right_count++;
		}
		else if (usetime>60 )
		{
			right_or_wrong="Time Out 60s     ";
		}
		else
		{
			right_or_wrong="calculate wrong.";
		}

		mvaddstr(16,11,"                ");


		mvprintw(18, 12, Result.c_str() );
		mvprintw(19, 12, right_or_wrong.c_str() );
		string Righttt=Int2Str(right_count);
		mvaddstr(22, 5, Righttt.c_str());
		string Sum=Int2Str(Sum_count);
		mvaddstr(22, 12, Sum.c_str());
		int rate=right_count*100/Sum_count;
		string Rtmp=Int2Str(rate)+"  ";
		mvaddstr(22, 23, Rtmp.c_str());
		attroff(attr);
		/*///
		  if (info.full)
		  {
		  mvprintw(3, 12, run.c_str() ); 
		//cout << "The result is: " << show_result() << '\n';
		}
		else
		{

		}
		///*///

		refresh();
	}
	endwin();

	return 0;

}





////////////////////////swimming in the sea & flying in the sky //////////////////

#endif //  Cal24_H_




