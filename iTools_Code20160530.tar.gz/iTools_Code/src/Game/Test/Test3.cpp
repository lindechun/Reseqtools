/* 
 * File:   newmain.cc
 * Author: Null
 * Blog: http://hi.baidu.com/hetaoos
 * Created on 2008��7��30��, ����12:49
 */


#include "pthread.h"
#include <iostream>
using namespace std ;
char A[100] ;
int B  ;

static void * run(void * null )
{
	while(true)    
	{
		char a=getchar();
		B++ ;
		if (B>100){B=99;}
		A[B]=a;
		if (a=='q' || a=='Q') {return NULL  ;}
		cout<<"IN\t"<<a<<endl;
		sleep(1);
	}
	return NULL ;
}

void *  dd(void * null )
{
	while(true)
	{
		if (B<0)
		{
			B=0;
			A[0]='c';
		}
		B--;
		cout<<"OUT\t"<<A[B]<<endl;
		if (A[B]=='q' || A[B]=='Q' ) {return NULL  ; }
		sleep(2);
	}
}

int main(int argc, char** argv)
{
	B=0;
	A[0]='c';
	pthread_t threads[2]; 
	pthread_attr_t attr; 
	pthread_create(&threads[0], NULL, run, NULL ) ;
	pthread_create(&threads[1], NULL, dd , NULL ) ;
	pthread_join(threads[0],NULL);
	cout<<"hewimingend"<<endl;
	pthread_join(threads[1],NULL);    
	cout<<"Love hewm"<<endl;
	//pthread_create(&threads[1], NULL, dd, NULL);
	return 0 ;
}



