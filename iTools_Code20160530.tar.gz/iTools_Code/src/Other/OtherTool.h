#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"
#include "fre.h"
#include "OtherLess.h"
#include "OtherSplit.h"
#include "OtherMerge.h"
#include "chi2.h"
#include "LD_Decay.h"
#include "Other_Ztest.h"
#include "All.genotype.h"

using namespace std;

int Fre_main(int argc, char **argv) ;
int all_genetype_main(int argc, char **argv) ;
int Other_Merge_main(int argc,char *argv[]) ;
int Other_split_main(int argc,char *argv[] ) ;
int Alg_View_main(int argc, char *argv[]) ;
int Other_less_main(int argc, char **argv);
int Chi2_X2_main(int argc, char ** argv ) ;
int Other_Ztest_main(int argc, char **argv) ;
int LDdecaySNP_main(int argc, char *argv[]);

static int  Other_usage ()
{
	cerr<<""
		"\n"
		"\tOther Tools Usage:\n\n"
		"\t\tsplit       split FILE(s) to SubFile By Raw-ID\n"
		"\t\tmsort       sort all FILE(s) quick & low memory\n"
		"\t\tmerge       merge multi Sort FILE(s) to a Sort FILE\n"
		"\t\tFre         stat Row Frequency Dis of FILE(s)\n"
		"\t\tAlg2geno    estimate genotype based soap,bam,sam\n"
		"\t\tview        view the Alignment[Bam,Sam,Soap]\n"
		"\t\tless        view the file like less\n"
		"\t\tchi2        get Chi2(X2) P-value (InPut:df chi2)\n"
		"\t\tZtest       get Zscore & P-value for a group number\n"
		"\t\tLDDecay     LD Decay form VCF/genotype (Dist ~ R^2)\n"
		"\n"        
		"\t\tHelp        Show this help\n"
		"\n";
	return 1;
}


int Other_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return Other_usage(); }
	else if (strcmp(argv[1], "Fre") == 0) { return Fre_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "split") == 0) { return Other_split_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "msort") == 0) { return msort_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "merge") == 0) { return Other_Merge_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Alg2geno") == 0) { return all_genetype_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "view") == 0) { return  Alg_View_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "less") == 0) { return  Other_less_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "LDDecay") == 0) { return  LDdecaySNP_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "chi2") == 0) { return  Chi2_X2_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Ztest") == 0) { return Other_Ztest_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0)  {  Other_usage(); }
	else
	{
		cerr<<"Other Tools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;	
}
