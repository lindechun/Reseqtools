#include "soap_snp.h"
#include "call_genotype.cc"
#include "chromosome.cc"
#include "matrix.cc"
#include "normal_dis.cc"
#include "prior.cc"
#include "rank_sum.cc"
#include "../../ALL/comm.h"
#include <getopt.h>

using namespace std;

int SoapSNPusage() {
    cerr<<"SoapSNP version 1.04 "<<endl;
    cerr<<"Compulsory Parameters:"<<endl;
    cerr<<"-i <FILE> Input SORTED Soap Result"<<endl;
    cerr<<"-d <FILE> Reference Sequence in fasta format"<<endl;
    cerr<<"-o <FILE> Output consensus file"<<endl;
    cerr<<"Optional Parameters:(Default in [])"<<endl;
    cerr<<"-z <Char> ASCII chracter standing for quality==0 [@]"<<endl;
    cerr<<"-g <Double> Global Error Dependency Coefficient, 0.0(complete dependent)~1.0(complete independent)[0.9]"<<endl;
    cerr<<"-p <Double> PCR Error Dependency Coefficient, 0.0(complete dependent)~1.0(complete independent)[0.5]"<<endl;
    cerr<<"-r <Double> novel altHOM prior probability [0.0005]"<<endl;
    cerr<<"-e <Double> novel HET prior probability [0.0010]"<<endl;
    cerr<<"-t set transition/transversion ratio to 2:1 in prior probability"<<endl;
    cerr<<"-s <FILE> Pre-formated dbSNP information"<<endl;
    cerr<<"-2 specify this option will REFINE SNPs using dbSNPs information [Off]"<<endl;
    cerr<<"-a <Double> Validated HET prior, if no allele frequency known [0.1]"<<endl;
    cerr<<"-b <Double> Validated altHOM prior, if no allele frequency known[0.05]"<<endl;
    cerr<<"-j <Double> Unvalidated HET prior, if no allele frequency known [0.02]"<<endl;
    cerr<<"-k <Double> Unvalidated altHOM rate, if no allele frequency known[0.01]"<<endl;
    cerr<<"-u Enable rank sum test to give HET further penalty for better accuracy. [Off]"<<endl;
    //cerr<<"-n Enable binomial probability calculation to give HET for better accuracy. [Off]"<<endl;
    cerr<<"-m Enable monoploid calling mode, this will ensure all consensus as HOM and you probably should SPECIFY higher altHOM rate. [Off]"<<endl;
    cerr<<"-q Only output potential SNPs. Useful in Text output mode. [Off]"<<endl;
    cerr<<"-M <FILE> Output the quality calibration matrix; the matrix can be reused with -I if you rerun the program"<<endl;
    cerr<<"-I <FILE> Input previous quality calibration matrix. It cannot be used simutaneously with -M"<<endl;
    cerr<<"-L <short> maximum length of read [100]"<<endl;
    cerr<<"-Q <short> maximum FASTQ quality score [41]"<<endl;
    cerr<<"-F <int> Output format. 0: Text; 1: GLFv2; 2: GPFv2.[0]"<<endl;
    cerr<<"-E <String> Extra headers EXCEPT CHROMOSOME FIELD specified in GLFv2 output. Format is \"TypeName1:DataName1:TypeName2:DataName2\"[""]"<<endl;
    cerr<<"-T <FILE> Only call consensus on regions specified in FILE. Format: ChrName\\tStart\\tEnd."<<endl;
    //cerr<<"-S <FILE> Output summary of consensus"<<endl;
    cerr<<"-h Display this help"<<endl;

    cerr<<"\nLicense GPLv3+: GNU GPL version 3 or later <http://gnu.org/licenses/gpl.html>"<<endl;
    cerr<<"This is free software: you are free to change and redistribute it."<<endl;
    cerr<<"There is NO WARRANTY, to the extent permitted by law.\n"<<endl;
    return 0;
}


int Var_SOAPSNP_main ( int argc, char * argv[]) {
    //	if (argc <=5 ) {  SoapSNPusage()  ;return 0;}
    // This part is the default values of all parameters
    Parameter * para = new Parameter;
    std::string alignment_name, consensus_name;
    bool is_matrix_in = false; // Generate the matrix or just read it?
    int c;
    int input_must=0;
    Files files;
    while((c=getopt(argc,argv,"i:d:o:z:g:p:r:e:ts:2a:b:j:k:unmqM:I:L:Q:S:F:E:T:h")) != -1) {
        switch(c) {
            case 'i':
                {
                    // Soap Alignment Result
                    files.soap_result.clear();
                    files.soap_result.open(optarg);
                    if( ! files.soap_result) {
                        cerr<<"No such file or directory:"<<optarg<<endl;;
                        delete para ; return 0 ;
                    }
                    alignment_name = optarg;
                    input_must+=1;
                    break;
                }
            case 'd':
                {
                    // The reference genome in fasta format
                    files.ref_seq.clear();
                    files.ref_seq.open(optarg);
                    if( ! files.ref_seq) {
                        cerr<<"No such file or directory:"<<optarg<<endl;
                        delete para ; return 0 ;
                    }
                    files.ref_seq.clear();
                    input_must+=1;
                    break;
                }
            case 'o':
                {
                    files.consensus.clear();
                    ///*////
                    string path=optarg ;
                    string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
                    if (ext=="gz" ||  ext=="glf" )
                    {

                    }
                    else if (ext=="cns" )
                    {
                        path=path+".gz";
                    }
                    else
                    {
                    //    cerr<<"warning: OutPut name suffix maybe no correct, we add '.cns'"<<endl;
                        path=path+".cns.gz";
                    }
                    optarg=const_cast<char*>(path.c_str());
                    ////*/////
                    files.consensus.open(optarg);
                    if( ! files.consensus ) {
                        cerr<<"Cannot creat file:" <<optarg <<endl;
                        delete para ; return 0 ;
                    }
                    files.consensus.clear();
                    consensus_name = optarg;
                    input_must+=1;
                    break;
                }
            case 'z':
                {
                    // The char stands for quality==0 in fastq format
                    para->q_min = optarg[0];
                    if(para->q_min == 33) {
                        clog<<"Standard Fastq System Set"<<endl;
                    }
                    else if(para->q_min == 64) {
                        clog<<"Illumina Fastq System Set"<<endl;
                    }
                    else {
                        clog<<"Other types of Fastq files?? Are you sure?"<<endl;
                    }
                    para->q_max = para->q_min + 41;
                    break;
                }
            case 'g':
                {
                    para->global_dependency= log10(atof(optarg));
                    break;
                }
            case 'p':
                {
                    para->pcr_dependency= log10(atof(optarg));
                    break;
                }
            case 'r':
                {
                    para->althom_novel_r = atof(optarg);
                    break;
                }
            case 'e':
                {
                    para->het_novel_r=atof(optarg);
                    break;
                }
            case 't':
                {
                    para->transition_dominant=true;
                    break;
                }
            case 's':
                {
                    // Optional: A pre-formated dbSNP table
                    files.dbsnp.clear();
                    files.dbsnp.open(optarg);
                    if( ! files.ref_seq) {
                        cerr<<"No such file or directory:"<<optarg<<endl;
                        delete para ; return 0 ;
                    }
                    files.dbsnp.clear();
                    break;
                }
            case '2':
                {
                    // Refine prior probability based on dbSNP information
                    para->refine_mode = true;
                    break;
                }
            case 'a':
                {
                    para->althom_val_r=atof(optarg);
                    break;
                }
            case 'b':
                {
                    para->het_val_r=atof(optarg);
                    break;
                }
            case 'j':
                {
                    para->althom_unval_r=atof(optarg);
                    break;
                }
            case 'k':
                {
                    para->het_unval_r=atof(optarg);
                    break;
                }
            case 'u':
                {
                    para->rank_sum_mode = true;
                    break;
                }
            case 'n':
                {
                    para->binom_mode = true;
                    break;
                }
            case 'm':
                {
                    para->is_monoploid=1;
                    break;
                }
            case 'q':
                {
                    para->is_snp_only=1;
                    break;
                }
            case 'M':
                {
                    files.matrix_file.close(); files.matrix_file.clear();
                    // Output the calibration matrix
                    files.matrix_file.open(optarg, fstream::out);
                    if( ! files.matrix_file) {
                        cerr<<"Cannot creat file :"<<optarg<<endl;
                        delete para ; return 0 ;
                    }
                    files.matrix_file.clear();
                    break;
                }
            case 'I':
                {
                    files.matrix_file.close(); files.matrix_file.clear();
                    // Input the calibration matrix
                    files.matrix_file.open(optarg, fstream::in);
                    if( ! files.matrix_file) {
                        cerr<<"No such file or directory:"<<optarg<<endl;
                        delete para ; return 0 ;
                    }
                    files.matrix_file.clear();
                    is_matrix_in = true;
                    break;
                }
            case 'S':
                {
                    //files.summary.open(optarg);
                    //// Output the summary of consensus
                    //if( ! files.summary ) {
                    //	cerr<<"No such file or directory: "<<optarg<<endl;
                    //	exit(1);
                    //}
                    break;
                }
            case 'L':
                {
                    para->read_length = atoi(optarg);
                    break;
                }
            case 'Q':
                {
                    para->q_max = optarg[0];
                    if(para->q_max < para->q_min) {
                        cerr<< "FASTQ quality character error: Q_MAX > Q_MIN" <<endl;
                    }
                    break;
                }
            case 'F': {
                          para->glf_format = atoi(optarg);
                          break;
                      }
            case 'E': {
                          para->glf_header = optarg;
                          break;
                      }
            case 'T': {
                          files.region.clear();
                          files.region.open(optarg);
                          files.region.clear();
                          para->region_only = true;
                          break;
                      }
            case 'h':
            case '?':SoapSNPusage();delete para ; return 0 ; break;
            default: cerr<<"Unknown error in command line parameters"<<endl;
        }
    }

    if( files.consensus.bad() || files.ref_seq.bad() || files.soap_result.bad() || input_must<3 ) {
        // These are compulsory parameters
        delete para  ;
        SoapSNPusage();
        return 0 ;
    }    
    //Read the chromosomes into memory
    Genome * genome = new Genome(files.ref_seq, files.dbsnp);
    files.ref_seq.close();
    files.dbsnp.close();
    clog<<"Reading Chromosome and dbSNP information Done."<<endl;
    if(para->region_only && files.region) {
        genome->read_region(files.region, para);
        clog<<"Read target region done."<<endl;
    }
    if(para->glf_format) { // GLF or GPF
        files.consensus.close();
        files.consensus.clear();
        string rmFile="rm -f " + consensus_name ;
        system (rmFile.c_str());
        //        OutGLF
        consensus_name=replace_all(consensus_name,".gz","");
        string ext =consensus_name.substr(consensus_name.rfind('.') ==string::npos ? consensus_name.length() : consensus_name.rfind('.') + 1);
        if ( ext=="cns" )
        {
            consensus_name=replace_all(consensus_name,".cns",".glf");
        }
        else if (ext=="gz" )
        {                    
            consensus_name=replace_all(consensus_name,".gz","");
        }
    	else if (ext=="glf" )
		{

		}
        else
        {
    //        cerr<<"warning: OutPut name suffix maybe no correct,we add '.glf' "<<endl;
            consensus_name=consensus_name+".glf";
        }

        files.OutGLF.open(consensus_name.c_str(), ios::binary);
        if(!files.OutGLF) {
            cerr<<"Cannot write result ot the specified output file."<<endl;
            delete genome ;
            delete para ; return 0 ;
        }
        if (1==para->glf_format) {
            files.OutGLF<<'g'<<'l'<<'f';
        }
        else if (2==para->glf_format) {
            files.OutGLF<<'g'<<'p'<<'f';
        }
        int major_ver = 0;
        int minor_ver = 0;
        files.OutGLF.write(reinterpret_cast<char*>(&major_ver), sizeof(major_ver));
        files.OutGLF.write(reinterpret_cast<char*>(&minor_ver), sizeof(minor_ver));
        if(!files.OutGLF.good()) {
            cerr<<"Broken ofstream after version."<<endl;
            delete genome ;
            delete para ; return 0 ;
        }
        std::string temp("");
        for(std::string::iterator iter=para->glf_header.begin();iter!=para->glf_header.end(); iter++) {
            if (':'==(*iter)) {
                int type_len(temp.size()+1);
                files.OutGLF.write(reinterpret_cast<char*>(&type_len), sizeof(type_len));
                files.OutGLF.write(temp.c_str(), temp.size()+1)<<flush;
                temp = "";
            }
            else {
                temp+=(*iter);
            }
        }
        if(!files.OutGLF.good()) {
            cerr<<"Broken ofstream after tags."<<endl;
            delete genome ;
            delete para ; return 0 ;
        }
        if(temp != "") {
            int type_len(temp.size()+1);
            files.OutGLF.write(reinterpret_cast<char*>(&type_len), sizeof(type_len));
            files.OutGLF.write(temp.c_str(), temp.size()+1)<<flush;
            temp = "";
        }
        int temp_int(12);
        files.OutGLF.write(reinterpret_cast<char*>(&temp_int), sizeof(temp_int));
        files.OutGLF.write("CHROMOSOMES", 12);
        temp_int = genome->chromosomes.size();
        files.OutGLF.write(reinterpret_cast<char*>(&temp_int), sizeof(temp_int));
        files.OutGLF<<flush;
        if(!files.OutGLF.good()) {
            cerr<<"Broken ofstream after writting header."<<endl;
            delete genome ;
            delete para ; return 0 ;
        }
    }
    Prob_matrix * mat = new Prob_matrix;
    if( ! is_matrix_in) {
        //Read the soap result and give the calibration matrix
        mat->matrix_gen(files.soap_result, para, genome);
        if (files.matrix_file) {
            mat->matrix_write(files.matrix_file, para);
        }
    }
    else {
        mat->matrix_read(files.matrix_file, para);
    }
    files.matrix_file.close();
    clog<<"Correction Matrix Done!"<<endl;
    mat->prior_gen(para);
    mat->rank_table_gen();
    Call_win info(para->read_length);
    info.initialize(0);
    //Call the consensus
    files.soap_result.close();
    files.soap_result.clear();
    files.soap_result.open(alignment_name.c_str());
    files.soap_result.clear();

    //	info.soap2cns(files.soap_result, files.consensus , genome, mat, para);
    info.soap2cns(files.soap_result, files  , genome, mat, para);

    if(para->glf_format) 
    {
        files.OutGLF.close();
    }
    else
    {
        files.consensus.close();
    }
    files.soap_result.close();
    delete mat;
    delete genome ;
    cerr<<"Consensus Done!"<<endl;
    return 1;
}

