// header file : hugeint.h
#ifndef _hugeint_H_
#define _hugeint_H_

#define MAXSIZE 1000

// implement file : hugeint.cpp
#include "include.h"
#include "source.h"


class hugeint
{
public:
	/************Constructor*******************************************/
	hugeint();//Default constructor
	hugeint(int);//Constructor with an int-type paramater
	hugeint(long);//Constructor with a long-type paramater
	hugeint(const char *);//Constructor with a string pointer paramater
	hugeint(const hugeint& val);//Constructor with an int-type paramater
	
	/************operators overloading*******************************************/
	// overloading = operator
	hugeint operator=(int);//overload = int
	hugeint operator=(long);//overload = long
	hugeint operator=(const char*);//overload = const char*
	hugeint operator=(const hugeint& val);//overload = const char*
	//maths operator overloading
	hugeint operator+(hugeint &); //overload+
	hugeint operator-(hugeint &);//overload-
	hugeint operator*(hugeint &);//overload*
	hugeint operator/(hugeint &);//overload/
	hugeint operator%(hugeint &);//overload%
    //Boolean calculation operator overloading
	bool operator>(hugeint &);//greater than 
	bool operator<(hugeint &);//les than
	bool operator!=(hugeint &);//not equal
	bool operator<=(hugeint &);//less equal
	bool operator>=(hugeint &);//greater equal
    bool operator==(hugeint &);//equal
    bool operator==(int);//equal
	hugeint& operator ++();//overload++  prefix
	hugeint operator ++(int);//overload++ postfix
	hugeint& operator --();//overload-- prefix
	hugeint operator --(int);//overload-- postfix
    //dualistic operator
    hugeint operator -=(hugeint &);//overload -=
	hugeint operator +=(hugeint &);//overload +=
	hugeint operator *=(hugeint &);//overload *=
	hugeint operator /=(hugeint &);//overload /=
	hugeint operator %=(hugeint &);//overload %=

	hugeint operator -=(long val);//overload -=
	hugeint operator +=(long val);//overload +=
	hugeint operator *=(long val);//overload *=
	hugeint operator /=(long val);//overload /=
	hugeint operator %=(long val);//overload %=

    hugeint operator -=(char* val);//overload -=
	hugeint operator +=(char* val);//overload +=
	hugeint operator *=(char* val);//overload *=
	hugeint operator /=(char* val);//overload /=
	hugeint operator %=(char* val);//overload %=
	/************calculate between hugeint and long, between hugeint and int********************************************/
	hugeint trans(long);//Convert long into hugeint
	hugeint operator +(long);//hugeint + long
	hugeint operator -(long);//hugeint - long
	hugeint operator *(long);//hugeint * long
	hugeint operator /(long);//hugeint / long
	hugeint operator %(long);//hugeint % long 
	/************calculate between hugeint and char* overload*******************************************/
	hugeint trans(char *);//Convert char* into hugeint
	hugeint operator +(char *);//hugeint + char*
	hugeint operator -(char *);//hugeint - char*
	hugeint operator *(char *);//hugeint * char*
	hugeint operator /(char *);//hugeint / char*
	hugeint operator %(char *);//hugeint % char*
	/************Output operator overload*******************************************/
	friend ostream &operator<<(ostream &, const hugeint &);//friend function <<
private:
	hugeint sub(hugeint &,hugeint &);//hugeint - hugeint
	hugeint add(hugeint &,hugeint &);//hugeint + hugeint  
	int		abscmp(hugeint &num);//abs
	char*	itoa(int value, char *str, int radix);
	char*	itoa(long value, char *str, int radix);
public:
	int m_data[MAXSIZE];//array to hold hugeint
	int m_sign;//1:+   -1:-
 	int m_nlen;//length of the hugeint
};

typedef hugeint		hint;
/*************constructor***********/
hugeint::hugeint()
{
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
}

hugeint::hugeint(int val)
{
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
	
	char temp[MAXSIZE]; 	
	
	if(val>=0) 
		m_sign=1; 
	else
	{
		m_sign=-1; 	
		val=abs(val); 
	}
	
	m_nlen=strlen(itoa(val,temp,10)); 
	for( int i=MAXSIZE-1; val!=0&&i>=0; i--)
	{
		m_data[i]=val%10; 
		val=val/10; 
	}
}

hugeint::hugeint(long val)
{
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
	
	char temp[MAXSIZE]; 	
	
	if(val>=0) 
		m_sign=1; 
	else
	{
		m_sign=-1; 	
		val=abs(val); 
	}
	
	m_nlen=strlen(itoa(val,temp,10)); 
	for( int i=MAXSIZE-1; val!=0&&i>=0; i--)
	{
		m_data[i]=val%10; 
		val=val/10; 
	}
}

hugeint::hugeint(const char *s)
{
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
	if(s==NULL)
	{
		m_nlen = 0;
		m_sign = 1;
		return;
	}
	int i,j;                 
	
	m_nlen=strlen(s); 			
	
	switch(s[0])
	{
	case '-':
	case '+':
		{
			for(i=MAXSIZE-1,j=m_nlen-1; i>MAXSIZE-m_nlen; i--,j--)
				m_data[i]=s[j]-'0'; 
			m_nlen=m_nlen-1;         
			
			if(s[0]=='+')
			{
				m_sign=1;            
			}
			
			if(s[0]=='-')
			{
				m_sign=-1;           
			}
			break; 	
		}
	default:				
		{
			m_sign=1; 			
			{
				for(i=MAXSIZE-strlen(s),j=0; i<=MAXSIZE-1; i++,j++)  	
					m_data[i]=s[j]-'0'; 
			}
			break; 
		}
	}	
}

hugeint::hugeint( const hugeint& val )
{
	memcpy(m_data, val.m_data, sizeof(val.m_data));
	m_sign = val.m_sign;
	m_nlen = val.m_nlen;
}

ostream& operator<<(ostream &output,const hugeint &val)
{
    int i;                    
    /*Remove 0 meaningless*/
    for(i=0; (val.m_data[i]==0)&&(i<=MAXSIZE-1); i++); 
    if(i==MAXSIZE)
	{output<<0;  return output; }
	
	else
	{//process negative number
		if(val.m_sign==-1)
			output<<"-"; 
	}
	for(; i<=MAXSIZE-1; i++)
		output<<val.m_data[i]; 
	return output; 
}
/*************compare between two abs hugeint***********/
int  hugeint::abscmp(hugeint &num)
{
	int i; 
	if(this->m_nlen<num.m_nlen) return -1; 
	if(this->m_nlen>num.m_nlen) return 1; 
	if(this->m_nlen==num.m_nlen)
	{
		for(i=MAXSIZE-num.m_nlen; i<MAXSIZE; i++)
		{
			if(this->m_data[i]==num.m_data[i]){continue; }
			if(this->m_data[i]>num.m_data[i]){return 1; }
			if(this->m_data[i]<num.m_data[i]){return -1; }
			return 0; 
		}
	}
	return 0; 
}

/************  = overload  ***********/
hugeint hugeint::operator=( int val )
{
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
	
	char temp[MAXSIZE]; 	
	
	if(val>=0) 
		m_sign=1; 
	else
	{
		m_sign=-1; 	
		val=abs(val); 
	}
	
	m_nlen=strlen(itoa(val,temp,10)); 
	for( int i=MAXSIZE-1; val!=0&&i>=0; i--)
	{
		m_data[i]=val%10; 
		val=val/10; 
	}

	return *this; 
}

hugeint hugeint::operator=( long val )
{
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
	
	char temp[MAXSIZE]; 	
	
	if(val>=0) 
		m_sign=1; 
	else
	{
		m_sign=-1; 	
		val=abs(val); 
	}
	
	m_nlen=strlen(itoa(val,temp,10)); 
	for( int i=MAXSIZE-1; val!=0&&i>=0; i--)
	{
		m_data[i]=val%10; 
		val=val/10; 
	}

	return *this; 
}

hugeint hugeint::operator=( const char* s )
{
	int i,j;                 
	memset(m_data, 0, sizeof(int)*MAXSIZE) ;			
	
	m_nlen=strlen(s); 			
	
	switch(s[0])
	{
	case '-':
	case '+':
		{
			for(i=MAXSIZE-1,j=m_nlen-1; i>MAXSIZE-m_nlen; i--,j--)
				m_data[i]=s[j]-'0'; 
			m_nlen=m_nlen-1;         
			
			if(s[0]=='+')
			{
				m_sign=1;            
			}
			
			if(s[0]=='-')
			{
				m_sign=-1;          
			}
			break; 	
		}
	default:				
		{
			m_sign=1; 			
			{
				for(i=MAXSIZE-strlen(s),j=0; i<=MAXSIZE-1; i++,j++)  	
					m_data[i]=s[j]-'0'; 
			}
			break; 
		}
	}
	
	return *this; 
}

hugeint hugeint::operator=( const hugeint& val )
{
	memcpy(m_data, val.m_data, sizeof(val.m_data));
	m_sign = val.m_sign;
	m_nlen = val.m_nlen;

	return *this;
}

bool hugeint::operator >( hugeint &val)
{
	if(m_sign > val.m_sign ) return true; 
	if (m_sign==1&&val.m_sign==1)
	{
		if(m_nlen>val.m_nlen)
			return true; 
		if(m_nlen<val.m_nlen)
			return false; 
		if(m_nlen==val.m_nlen)
		{
			int i=MAXSIZE-m_nlen; 	       
			for(; i<MAXSIZE; i++)
			{
				if(m_data[i]>val.m_data[i]) return true; 
				if(m_data[i]<val.m_data[i]) return false; 
				if(m_data[i]==val.m_data[i]) continue; 
			}
		}
	}
	else if (m_sign==-1&&val.m_sign==-1)
	{
		if(m_nlen<val.m_nlen)
			return true; 		
		if(m_nlen>val.m_nlen)
			return false; 
		
		if(m_nlen==val.m_nlen)
		{                       
			int i=MAXSIZE-m_nlen; 	       
			for(; i<MAXSIZE; i++)
			{
				if(m_data[i]<val.m_data[i]) return true; 
				if(m_data[i]>val.m_data[i]) return false; 	
				if(m_data[i]==val.m_data[i]) continue; 
			}		 
		}	
	}
	return false; 
}

bool hugeint::operator ==( hugeint &val)
{
	if ((m_sign==val.m_sign)&&(m_nlen==val.m_nlen))
	{
		for(int i=MAXSIZE-1; i>=0; i--)
			if(m_data[i]!=val.m_data[i]) return false;
			return true; 
	}
	else return false; 
	
}

bool hugeint::operator==( int val)
{
	hugeint	tmp = val;
	return (*this)==tmp;
}

bool hugeint::operator !=( hugeint &val)
{
	if((*this)==val) 
		return false; 
	else 
		return true; 
}

bool hugeint::operator >=( hugeint &val)
{
	if(*this>val||*this==val)return true; 
	else return false; 
}

bool hugeint::operator <( hugeint &val)
{
	if(!(*this>=val))return true; 
	else return false; 
}

bool hugeint::operator <=( hugeint &val)
{
	if(!(*this>val)) return true; 
	else return false; 
}

hugeint hugeint::add(hugeint &temp1,hugeint &temp2)
{
	hugeint a("0"),b("0"); 
	a=temp1; 
	b=temp2; 
	hugeint result("0"); 
	int i, j; 
	if(temp1.m_nlen>=temp2.m_nlen){j=temp1.m_nlen; }
	else {j=temp2.m_nlen; }
	for(i=MAXSIZE-1;  i>=(MAXSIZE-j-1);  i--)			
	{
		if(temp1.m_data[i]+temp2.m_data[i]<=9)            
			result.m_data[i]=(temp1.m_data[i]+temp2.m_data[i]); 
		else
		{
            temp1.m_data[i-1]+=1;                       
            result.m_data[i]=(temp1.m_data[i]+temp2.m_data[i])%10;  
		}   
	} 
	result.m_nlen=MAXSIZE-1-i; 
	temp1=a; 
	temp2=b; 
	return result;                                      
}

/*********(+,+),(-,-),(+,-),(-,+)***********/
hugeint hugeint::operator +(hugeint& val)
{
	hugeint result("0"); 
	int carry=0;
	
	if(m_sign==val.m_sign)
	{
		if(m_sign==1&&val.m_sign==1)//(+,+)
		{
			result=add((*this),val); 
			return result; 
		}
		else//(-,-)
		{
			result=add((*this),val); 
			result.m_sign=-1; 
			return result; 
		}
	}
	else//(+,-)||(-,+)
	{
		if((*this).m_sign==1&&val.m_sign==-1)//(+,-)
		{
			hugeint temp1("0"),temp2("0"); 
			int i;           
			temp1=(*this); 
			temp2=val; 
			if(temp1.abscmp(temp2)==1)
			{
				result=sub(temp1,temp2); //Attention��temp1-temp2 > 0;
				result.m_sign=1; 
				for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
				result.m_nlen=MAXSIZE-i; 
				return result; 
			}
			if(temp1.abscmp(temp2)==(-1))
			{
				result=sub(temp2,temp1); 			
				int i; 
				result.m_sign=-1; 		
				for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
				result.m_nlen=MAXSIZE-i; 
				return result; 
			}
		}
		if((*this).m_sign==-1&&val.m_sign==1)//(-,+)
		{
			hugeint temp1("0"),temp2("0"); 
			int i;           
			temp1=*this; 		
			temp2=val; 
			
			if(temp1.abscmp(temp2)==1)
			{
				result=sub(temp1,temp2); 
				result.m_sign=-1; 
				for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
				result.m_nlen=MAXSIZE-i; 
				return result; 
			}
			if(temp1.abscmp(temp2)==(-1))
			{
				result=sub(temp2,temp1); 			
				int i; 
				result.m_sign=1; 				
				for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
				result.m_nlen=MAXSIZE-i; 
				return result; 
			}
		}
		else {return 0; }
	}
	return 0; 
}

hugeint hugeint::sub(hugeint &temp1,hugeint &temp2)
{
	hugeint result("0"); 
	for(int i=MAXSIZE-1;  i>=MAXSIZE-temp1.m_nlen;  i--)			
	{
		if(temp1.m_data[i]>=temp2.m_data[i]) 
			result.m_data[i]=temp1.m_data[i]-temp2.m_data[i]; 
		else
		{
            temp1.m_data[i-1]-=1;
            result.m_data[i]=temp1.m_data[i]+10-temp2.m_data[i];  
		}   
	} 
	return result;                                     
}

hugeint hugeint::operator -(hugeint &val)
{

	hugeint max("0"),min("0"),result("0"); 
	if((*this)==(val))
		return 0; 
	
	if((*this).m_sign==val.m_sign&&val.m_sign==1)//(+,+)
	{
		hugeint temp1("0"),temp2("0"); 
		int i;           
		temp1=*this; 
		temp2=val; 
		if(temp1.abscmp(temp2)==1)
		{
			result=sub(temp1,temp2); 
			result.m_sign=1; 
			for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
			result.m_nlen=MAXSIZE-i; 
			return result; 
		}
		if(temp1.abscmp(temp2)==(-1))
		{
			result=sub(temp2,temp1); 			
			int i; 
			result.m_sign=-1; 				
			for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
			result.m_nlen=MAXSIZE-i; 
			return result; 
		}
	}
	else if((*this).m_sign==val.m_sign&&val.m_sign==-1)//(-,-)
	{
		hugeint temp1("0"),temp2("0"); 
		int i; 
		temp1=*this; //*this��ֵ��temp1
		temp2=val; //val��ֵ��temp2
		
		if(temp1.abscmp(temp2)==1)
		{
			result=sub(temp1,temp2); 
			result.m_sign=-1; 
			for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
			result.m_nlen=MAXSIZE-i; 
			return result; 
		}
		if(temp1.abscmp(temp2)==(-1))
		{
			result=sub(temp2,temp1); 			
			int i; 
			result.m_sign=1; 				
			for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
			result.m_nlen=MAXSIZE-i; 
			return result; 
		}
	}
	else if((*this).m_sign==1&&val.m_sign==-1)//(+,-)
	{
		hugeint temp1("0"),temp2("0"); 
		temp1=*this; 
		temp2=val; 
		int i; 
		temp2.m_sign=1; 				
		result=temp1+temp2; 
		result.m_sign=1; 
		for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
		result.m_nlen=MAXSIZE-i; 		
		return result; 
	}
	else if((*this).m_sign==-1&&val.m_sign==1)//(-,+)
	{
		hugeint temp1("0"),temp2("0"); 
		temp1=*this; 
		temp2=val; 		
		temp1.m_sign=1; 
		int i; 
		result=temp1+temp2; 
		result.m_sign=-1; 
		for(i=0; i<MAXSIZE&&result.m_data[i]==0; i++); 
		result.m_nlen=MAXSIZE-i; 
		return result; 
	}
	else return 0; 
	return 0;
}
/*************  +=overload  ***********/
hugeint hugeint::operator +=(hugeint &val)
{
	*this=*this+(val); 
	return *this; 
}

hugeint hugeint::operator+=( long val )
{
	*this=*this+(val); 
	return *this; 
}

hugeint hugeint::operator+=( char* val )
{
	*this=*this+(val); 
	return *this; 
}

/*************  -=overload  ***********/
hugeint hugeint::operator -=(hugeint &val)
{
	*this=(*this)-val; 
	return *this; 
} 

hugeint hugeint::operator-=( long val )
{
	*this=(*this)-val; 
	return *this; 
}

hugeint hugeint::operator-=( char* val )
{
	*this=(*this)-val; 
	return *this; 
}
///*************  prefix ++ overload   ***********/
hugeint& hugeint::operator ++()
{
	hugeint one("1"); 
	*this+=one; 
	return *this; 
}
/*************   postfix ++ overload   ***********/
hugeint hugeint::operator ++(int)
{
	hugeint old=*this; 
	++(*this); 
	return old; 
}
/*************   prefix-- overload   ***********/
hugeint& hugeint::operator --()
{
	hugeint one("1"); 
	*this-=one; 
	return *this; 
} 
/*************   postfix-- overload    ***********/
hugeint hugeint::operator --(int)
{
	hugeint old=*this; 
	--(*this); 	
	return old; 
}

/*************  overload*    ***********/
hugeint hugeint::operator *(hugeint &val)
{
	hugeint result1,result2,result("0");
	result1=(*this); 
	result2=(val); 
	
	int a[MAXSIZE],b[MAXSIZE],c[MAXSIZE]; 
	int n,m,d,w,x,y,z,i,j,nn,nnn,mm; 	 
	n=(*this).m_nlen; 
	nn=n; 
    m=val.m_nlen; 
	mm=m; 
    nnn=nn+mm; 
	if(this->m_sign!=val.m_sign)
	{
		result.m_sign=-1; 	
	}
	else
	{
		result.m_sign=1; 	
	}
	
	
	for(i=MAXSIZE-1; n>=0; i--)
	{
		a[--n]=this->m_data[i]; 
	}
	for(j=MAXSIZE-1; m>=0; j--)
	{
		b[--m]=val.m_data[j]; 
	}
	for(d=0; d<MAXSIZE; d++)
        c[d]=0; 
	for(i=0; i<nn; i++)
	{   
		for(j=0; j<mm; j++)
		{
			x=(a[nn-i-1])*(b[mm-j-1]);       
			y=x/10; 			//carry or not
			z=x%10; 			
			w=i+j+1; 			
			c[w]=c[w]+z; 		
			c[w+1]=c[w+1]+y+c[w]/10;   
			c[w]=c[w]%10;     
		}
	}
	if(c[nnn]==0)   
		nnn=nnn-1;   
    int numm; 
	numm=nnn; 
	for(i=MAXSIZE-nnn; i<MAXSIZE; i++)
	{
		result.m_data[i]=c[nnn--]; 
	}	
	result.m_nlen=numm; 
	
	(*this)=result1; 
	(val)=result2; 
	return result; 
}

hugeint hugeint::operator/(hugeint &val)
{
	hugeint result1,result2; 
	result1=(*this); 
	result2=(val); 
	
	if (this->m_nlen<val.m_nlen) 
		return 0; 
	
	hugeint mydiv(0),result(0),aa("1"),bb(0000),valaa(0),valaabb(0),valaabb2(0),bb2(0),zero("0"),kk(0),ten("10"),yi("1"); 
	int n,m; 
	n=this->m_nlen; 
	m=val.m_nlen; 
	/**********************************************have sign*************************/
	
	if(this->m_sign!=val.m_sign)
	{
		result.m_sign=-1; 
	}
	else
	{
		result.m_sign=1; 
	}
	
    if(this->m_sign==-1)
	{
		(*this).m_sign=1; 
	}
	
	if(val.m_sign==-1)
	{
		val.m_sign=1; 
	}
	/********************************************************************************/
	int valm,fag=0; 
	mydiv=(*this); 
	result.m_nlen = 0;
	
	for(int i=n-m+1; i>=0; i--)
	{
		for(int j=0; j<=9; j++)
		{
			int k; 
			aa=yi; 
			for(k=i; k>0; k--)
			{
				aa=aa*ten; 	
			}
			bb=(this->trans(j)); 		
			bb2=(this->trans(j+1)); 	
			
			valaa=val*aa; 				
			valaabb=valaa*bb; 			
			valaabb2=valaa*bb2; 	
			if((valaabb>mydiv))	
			{
				break; 
			}
			if(valaabb2>mydiv)
			{
				if(valaabb<=mydiv)	
				{
					result.m_data[MAXSIZE-1-i]=j; 
					if (result.m_nlen != 0)
					{
						result.m_nlen = MAX(i+1, result.m_nlen);
					}
					else result.m_nlen = i+1;
					if(fag==0)
					{
						valm=MAXSIZE-1-i; 
						fag=1; 
					}
					
					mydiv=(mydiv-valaabb); 
					break; 
				}
				
			}
		}
	}
	
	(*this)=result1; 
	(val)=result2; 
	return result; 
}

hugeint hugeint::operator%(hugeint &val)
{
	hugeint result1,result2; 
	result1=(*this); 
	result2=(val); 
	
	if (this->m_nlen<val.m_nlen) 
		return (*this); 
	
	hugeint mydiv(0),result(0),aa("1"),bb(0000),valaa(0),valaabb(0),valaabb2(0),bb2(0),zero("0"),kk(0),ten("10"),yi("1"); 
	int n,m; 
	n=this->m_nlen; 
	m=val.m_nlen; 
	/**********************************************have sign*************************/
	if(this->m_sign!=val.m_sign)
	{
		result.m_sign=-1; 
	}
	else
	{
		result.m_sign=1; 
	}
	
    if(this->m_sign==-1)
	{
		(*this).m_sign=1; 
	}
	
	if(val.m_sign==-1)
	{
		val.m_sign=1; 
	}
	/*******************************************************************************/
	int valm,fag=0; 
	mydiv=(*this); 
	
	for(int i=n-m+1; i>=0; i--)
	{
		for(int j=0; j<=9; j++)
		{
			int k; 
			aa=yi; 
			for(k=i; k>0; k--)	
			{
				aa=aa*ten; 		
			}
			
			bb=(this->trans(j)); 
			bb2=(this->trans(j+1)); 
			
			valaa=val*aa; 	
			valaabb=valaa*bb; 	
			valaabb2=valaa*bb2; 
			if((valaabb>mydiv))	
			{
				break; 
			}
			if(valaabb2>mydiv)	
			{
				if(valaabb<=mydiv)
				{
					result.m_data[MAXSIZE-1-i]=j; 
					if(fag==0)
					{
						valm=MAXSIZE-1-i; 
						fag=1; 
					}
					mydiv=(mydiv-valaabb); 
					break; 
				}
				
			}
		}
	}
	(*this)=result1; 
	(val)=result2; 
	return mydiv; 
}

hugeint hugeint::operator *=(hugeint &val)
{
	*this=*this*val; 
	return *this; 
}

hugeint hugeint::operator*=( long val )
{
	*this=*this*val; 
	return *this; 
}

hugeint hugeint::operator*=( char* val )
{
	*this=*this*val; 
	return *this; 
}

hugeint hugeint::operator /=(hugeint &val)
{
	*this=*this/val; 
	return *this; 
}

hugeint hugeint::operator/=( long val )
{
	*this=*this/val; 
	return *this; 
}

hugeint hugeint::operator/=( char* val )
{
	*this=*this/val; 
	return *this; 
}

hugeint hugeint::operator %=(hugeint &val)
{
	*this=*this%val; 
	return *this; 
}

hugeint hugeint::operator%=( long val )
{
	hugeint temp(val);
	*this=*this%temp; 
	return *this; 
}

hugeint hugeint::operator%=( char* val )
{
	hugeint temp(val);
	*this=*this%temp; 
	return *this; 
}

hugeint hugeint::trans(long val)
{	
	char temp[MAXSIZE]; 
	hugeint result("0"); 	
	
	if(val>=0) 
		result.m_sign=1; 
	else
	{
		result.m_sign=-1; 	
		val=abs(val); 
	}
	
	result.m_nlen=strlen(itoa(val,temp,10)); 
	for(int i=MAXSIZE-1; val!=0&&i>=0; i--)
	{
		result.m_data[i]=val%10; 
		val=val/10; 
	}
	return result; 	
}

hugeint hugeint::operator +(long val)
{
	hugeint temp(val); 
	hugeint result("0"); 
    result=*this+temp;
	return result; 
}

hugeint hugeint::operator -(long val)
{
	hugeint temp(val); 
	hugeint result("0"); 
	result=*this-temp; 
	return result; 
}

hugeint hugeint::operator *(long val)
{
	hugeint temp("0"); 
	hugeint result("0"); 
	temp=trans(val); 
	result=*this*temp; 
	return result; 
}

hugeint hugeint::operator /(long val)
{
	hugeint temp("0"); 
	hugeint result("0"); 
    temp=trans(val); 
	result=*this/temp; 
	return result; 
}

hugeint hugeint::operator %(long val)
{
	hugeint temp("0"); 
	hugeint result("0"); 
    temp=trans(val); 
	result=*this%temp; 
	return result; 
}

hugeint hugeint::trans(char *string)
{
	hugeint temp("0"); 
	int i,j,l; 
	for(i=0; i<=MAXSIZE-1; i++)
		temp.m_data[i]=0; 
	
	l=strlen(string); 
	
	switch(string[0])
	{
	case '-':
	case '+':
		{
			for(i=MAXSIZE-1,j=l-1; i>MAXSIZE-l; i--,j--)
				temp.m_data[i]=string[j]-'0'; 
			//i++; 
			if(string[0]=='+')
			{
				temp.m_sign=1; 
				temp.m_nlen=l-1; 
			}
			
			
			if(string[0]=='-')
			{
				temp.m_sign=-1; 
				temp.m_nlen=l-1; 
			}
			break; 	
		}
	default:
		{
			temp.m_sign=1; 
			{
				for(i=MAXSIZE-strlen(string),j=0; i<=MAXSIZE-1; i++,j++)
					temp.m_data[i]=string[j]-'0'; 
				temp.m_nlen=l; 
			}
			break; 
		}
	}	
	return temp; 	
}

hugeint hugeint::operator +(char *val)
{
	hugeint temp("0"); 
	hugeint result("0");
	temp=trans(val);
    result=*this+temp;
	return result; 
}

hugeint hugeint::operator -(char *val)
{
	hugeint temp("0"); 
	hugeint result("0");
	temp=trans(val);
	result=*this-temp;
	return result; 
}

hugeint hugeint::operator *(char *val)
{
	hugeint temp("0"); 
	hugeint result("0"); 
	temp=trans(val);
	result=*this*temp; 
	return result; 
}

hugeint hugeint::operator /(char *val)
{
	hugeint temp("0"); 
	hugeint result("0"); 
    temp=trans(val); 
	result=*this/temp; 
	return result; 
}

hugeint hugeint::operator %(char *val)
{
	hugeint temp("0"); 
	hugeint result("0");
    temp=trans(val);
	result=*this%temp;
	return result; 
}

char* hugeint::itoa( int value, char *str, int radix )
{
	sprintf(str, "%d", value); 
	return str; 
}

char* hugeint::itoa( long value, char *str, int radix )
{
	sprintf(str, "%d", value); 
	return str; 
}

#endif //_hugeint_H_
