#include "include.h"
#include "common.h"
#include "source.h"
//*
#include "len2chrome.h"
#include "align2pe.h"
#include "findSV.h"
#include "filtersv.h"
#include "simplify.h"
//*/
//Maintained	by Haikuan Zhang
//Modified		Date:	Wed Dec 15 10:10:37 CST 2010
/////////////// Readme /////////////////////////////
BEGIN_README
"This program is used to find structural variations(SV). \n"
"This program has four modules, and each module can execute independently if given right input parameters."
"In default, all modules executes orderly. In soap.l includes all file names to be processed, and soap data is"
"arranged by len--the raw soap output. If commond -2 exist, all input file must have been rearranged by chromosome,"
"while -3: pair end files, -4: *.sv files.\n\n"
"Usage:\n"
"	[Options]        [Functions]\n"
"	-h --help -help  Call help.\n"
"	-i <str>	 *.l or *.lst or *.list. Include all filename, the file can be .gz format. If not, it will be considered as a single source file.\n"
"	-cl <int>	 Indicate the minimum count of pair ends in one cluster. Default is [3]\n"
"	-o <str>	 Output directory to include the result.Default (./)\n"
"	-insert <str>    File of insert size information:\n"
"			 	Format1 : len_id  insert_size  left_sd  right_sd.\n"
"			 	Format2 : len_id  insert_size  sd.\t( old [before soapsv1.01] Format : id_len  insert_size  sd ).\n"
"			 Dierect Value:(just for single len)\n"
"				Format1 : insert_size  left_sd  right_sd.\n"
"				Format2 : insert_size  sd.\n"	
"	-gap <str>	 gap file. Format : chromeid   start   end \n"
"	-cpu <int>	 cpu for work. Default [4]\n"
"	-Q <int>	 quality limit. Default [1], unique match.\n"
"	-cluster	 Output cluster information into .cluster files.\n"
"	-image		 Draw SV image in png format.\n"
"	-normal		 Output normal PE\n"
"	-sim		 Do mixed chromosome soap result,  designed for thousands of reference and each reference is short than 10M. \n"
"	-2		 Execute from align2pe, if soap result have been split by chromosome.\n"
"	-3		 Execute from findsv, if input files are *.PE format.\n"
"	-4		 Execute from filtersv, if *.sv exists.\n"
"example:\n"
"	./soapsv -i soap.l -o result/ -insert 209-12 -gap file.gap -cl 5     //For a series of file,but one len\n"
"	./soapsv -i soap.l -o result/ -insert insertsize_info -gap file.gap -cl 5 //For a series of file. With insert_info file\n"
"	./soapsv -i file.soap -o result/ -insert 209-12-10 -gap file.gap -cl 5 -c2      //For a single file, Execute from align2pe.\n"
"\n"
END_README

VString		g_module;

//int main(int argc, char* argv[])
int Var_SOAPSV_main(int argc, char* argv[])
{
	START_TIMER;
	if (argc == 1)
	{
		README;
		return 0;
	}
	else
	{
		for (int i=1; i<argc; i++)
		{
			if(strcmp(argv[i], "-h")==0 || strcmp(argv[i], "--help")==0 || strcmp(argv[i], "-help")==0)
			{
				README;
				return 0;
			}
		}
	}
	AfxGetOptions(argc, argv);
	string flag(AfxGetValue("-insert"));
	string suffix(".re");
//	string name=flag+suffix;
	if(AfxGetValue("-sim") != NULL)
	{//new version
		main_simplify(argc, argv);
		END_TIMER;
		return 0;
	}
	
	// old version
	global_param	gp;
	if(main_len2chrome(argc, argv, (void*)&gp) == 0){cerr<<"len2chrome failed!"<<endl;return 0;}
	if(main_align2pe(argc, argv, (void*)&gp) == 0){cerr<<"align2pe failed!"<<endl;return 0;}
	if(main_findsv(argc, argv, (void*)&gp) == 0){cerr<<"findsv failed!"<<endl;return 0;}
	if(main_filtersv(argc, argv, (void*)&gp) == 0){cerr<<"filtersv failed!"<<endl;return 0;}
	
//	ofstream outfile(name.c_str());
//	outfile << "ok, is done!" << endl;
//	outfile.close();

	END_TIMER;
	return 0;
	////////////////////////////////
}




/*****************************************************************************/
/***************************code under is no use now**************************/
// Use dynamic links library. Compile the four modules to *.so.
/*
bool LoadModule(global_param& gp, const char* pSo, const char* pName, int argc, char** argv)
{
	typedef int (*pMainFunc)(int, char**, void*);
	void *phandle = dlopen(pSo, RTLD_LAZY);
	if (phandle == NULL || dlerror()!=NULL)
	{
		printf("dlopen() error!\n");
		return false;
	}
	pMainFunc   pMain = (pMainFunc)dlsym(phandle, pName);
	if (dlerror() != NULL)
	{
		printf("dlsym() error!\n");
		dlclose(phandle);	
		return false;
	}
	if (pMain(argc, argv, (void*)&gp) == 0)
	{
		dlclose(phandle);	
		return false;
	}
	dlclose(phandle);	
	return true;
}

void InitModule(char** argv)
{
	string	str = argv[0];
	int		pos = 0;
	if ((pos=str.rfind('/'))==-1)
		str = "";
	else
		str = str.substr(0, pos+1);
	string	tmp = str;
	g_module.push_back(tmp+="len2chrome.mo");
	g_module.push_back("main_len2chrome");
	tmp = str;
	g_module.push_back(tmp+="align2pe.mo");
	g_module.push_back("main_align2pe");
	tmp = str;
	g_module.push_back(tmp+="findsv.mo");
	g_module.push_back("main_findsv");
	tmp = str;
	g_module.push_back(tmp+="filtersv.mo");
	g_module.push_back("main_filtersv");
}
*/
