#ifndef _COMMON_SVH_
#define _COMMON_SVH_

#include "type.h"
//#include "hugeint.h"
#include "_common_struct.h"
#include "Findfile.h"
#include "global.h"
#include "table.h"
#include "graphic.h"
//#include "source.h"
//#include "calendar.h"
//#include "string_ex.h"
#include "threadmanager.h"
/**************/
#endif
