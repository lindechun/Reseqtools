#ifndef _SOURCE_H_
#define _SOURCE_H_

#include "type.h"

#ifndef MAX
#define MAX(a,b) a>b?a:b
#endif

#ifndef MIN
#define MIN(a,b) a<b?a:b 
#endif

#ifndef MAXMIN
#define MAXMIN(mx,mi,a,b)	{if (a<b){\
									mx=b;mi=a;\
								} else{\
									mx=a;mi=b;\
								}\
							}
#endif

#ifndef __P2
#define __P2(a)	a*a 
#endif

#ifndef PI
#define PI	3.1415926
#endif

#ifndef	Safe_DeleteVec
#define Safe_DeleteVec(p) {if(p != NULL){delete []p; p = NULL;}}
#endif

#ifndef Safe_Delete
#define Safe_Delete(p) {if(p != NULL){delete p; p = NULL;}}
#endif

#define BEGIN_README	char readme[] = "\33[31m*******************************************Readme******************************************\n"
#define END_README "Author : zhangkui@genomics.org.cn	Code Maintenance : zhanghaikuan@genomics.org.cn\n"\
"*******************************************************************************************\33[00m";
#define README cout<<readme<<endl;
#define HELP	README
#define USAGE 	README

#define START_TIMER  	timeval		__tvs, __tve;\
						gettimeofday(&__tvs, NULL);
#define END_TIMER		gettimeofday(&__tve, NULL);\
						float		__sec__t = __tve.tv_sec-__tvs.tv_sec;\
						if (__tve.tv_usec < __tvs.tv_usec)\
						{	__sec__t -= 1;\
							__sec__t += float((__tve.tv_usec+1000000-__tvs.tv_usec)%1000000)/float(1000000);\
						}else {__sec__t += float((__tve.tv_usec+1000000-__tvs.tv_usec)%1000000)/float(1000000);}\
						char __tmp_t[100];\
						sprintf(__tmp_t,"Run time : %.2fs", __sec__t);\
						cerr<<__tmp_t<<endl;


#ifdef _TYPE_H_
#define RGB(r,g,b)			((COLORREF)(((BYTE)(r)|((WORD)((BYTE)(g))<<8))|(((DWORD)(BYTE)(b))<<16)))
#define R(rgb)				((BYTE)(rgb))
#define G(rgb)				((BYTE)(((WORD)(rgb)) >> 8))
#define B(rgb)				((BYTE)((rgb)>>16))
#endif

#endif
