//header file : align2pe.h
#ifndef _BamALIGN2PE_H_
#define _BamALIGN2PE_H_
/*Multithread parameter struct*/
/************************************************************************/
#define	CH(a,b)		((a<<1)|b)
/************************************************************************/

#include "include.h"
#include "common.h"
#include "main.h"
#include "align2pe.h"
#include "../../Soap/xam2soap/TSamCtrl.h"

//////////////////////////////////////////////////////////////////////////
class BamAlign2pe
{
	public:
		BamAlign2pe();
		BamAlign2pe(MInsertSD* pis)
		{
			char* pq = AfxGetValue("-Q");
			m_nqual = (pq==NULL) ? 20 : atoi(pq);//默认为唯一比上的pair  reads
			m_pminsert = pis;	
			m_cc['+'] = 0;
			m_cc['-'] = 1;
			m_mcc['0'] = '3';
			m_mcc['1'] = '2';
			m_mcc['2'] = '1';
			m_mcc['3'] = '0';
			m_mcc['4'] = '4';
			m_mcc['5'] = '5';
			m_bnormal = false;
			m_breverse = AfxGetValue("-R")==NULL?false:true;//use for test.
		}
		~BamAlign2pe();

		void		 pe_convsoap2pe(const char* pName, VString& vstr);
		void		 pe_readgap(const char* p, map<string, vector<SGAP> >* pgap);
		bool		 pe_getinsertinfo(MInsertSD* p);// Get insert size information

		static bool	 pe_checknormal(Pair_End& pe1, Pair_End& pe2, char& ch);//PE 是否为正常PE，处于[insert－3sd,insert+3sd]视为正常PE，方向不同的都为 异常PE
		static void	 pe_parseID(string& str);//去掉soap id之后的 /1 & /2

	private:
		bool	 	 pe_checkgap(int ns, int ne);
		void	 	 Bampe_outputPE(Pair_End& pe1, Pair_End& pe2, ofstream& ofile);//输出PE
		void	 	 Bampe_outputPE(string& str, MPAIREND& vpe, ofstream& ofile);//输出PE
	public:
		//Attribute
		map<char, char>			m_mcc;// Convert RF to FR  如果比对正方向为RF则把RF 转换为FR
	private:
		//Attribute
		vector<SGAP>*			m_vgap;// Gap on reference info
		MInsertSD*				m_pminsert;// Insert size and sd info
		map<char, int>			m_cc;  // '+'=>0   '-'=>1
		int						m_nqual;// Unique map or not
		string					m_strchr;
		bool					m_breverse;// for test . 
		bool					m_bnormal;// Output normal PE
};

extern bool g_binsertfile;
//////////////////////////////////////////////////////////////////////////
//inline functions
inline void BamAlign2pe::pe_parseID( string& str )
{
	int		pos;
	if((pos=str.find('/'))!=-1)
		str.assign(str, 0, pos);
}

inline bool BamAlign2pe::pe_checkgap( int ns, int ne )
{
	if (m_vgap == NULL)
		return false;

	for (int i=0; i<m_vgap->size(); i++)
	{
		if (!(ne<m_vgap->operator [](i).ns || ns>m_vgap->operator [](i).ne))
		{
			return true;
		}
	}
	return false;
}

inline bool BamAlign2pe::pe_checknormal( Pair_End& pe1, Pair_End& pe2, char& ch )
{
	if(ch == '1')
	{	
		int		len = pe2.npos - pe1.npos + pe2.nrlen;
		if(len <= pe1.nmean-3*pe1.nsd)ch = '4';
		else if(len < pe1.nmean+3*pe1.nrsd)ch = '5';	//right sd value
		if(ch == '5')return true;
	}
	return false;
}

inline void BamAlign2pe::Bampe_outputPE( string& str, MPAIREND& mpe, ofstream& ofile )
{//for soap
	VString		vstr;
	split(str, vstr, "\t ");
	if(vstr.size()<11)return;

	Pair_End	pe;
	pe.nqual	= atoi(vstr[4].c_str());		
	if( vstr[5] =="*" ||  vstr[2] =="*"  ) return;
	if(pe.nqual<m_nqual) return;
	int flag = atoi(vstr[1].c_str());

	pe_parseID(vstr[0]);

	pe.strid	= vstr[0];
	pe.ch		=  ((flag & (0x1 << 4)) ? '-' : '+') ;
	pe.npos		= atoi(vstr[3].c_str());
	pe.nrlen    = 	Tcount_Read_len(vstr[5]);//vstr[9].length();
	if(!g_binsertfile)
	{
		pe.nmean = m_pminsert->operator []("*").ninsert;
		pe.nsd	 = m_pminsert->operator []("*").nsd;

		pe.nrsd	 = m_pminsert->operator []("*").nrsd;
	}
	else		// get the insert information from m_pminsert
	{
		string	tmp;
		int		pos;
		if(vstr[0].find('-') == -1)return;
		tmp = vstr[0].substr(0, vstr[0].find('-'));	// 11-9340372 , 11 is the number of len, in insert_info file is the number.

		pe.nmean = m_pminsert->operator [](tmp).ninsert;
		pe.nsd	 = m_pminsert->operator [](tmp).nsd;

		pe.nrsd	 = m_pminsert->operator [](tmp).nrsd;
		if(pe.nmean==0 || pe.nsd==0)return;
	}


	if (mpe.find(vstr[0]) != mpe.end())
	{

		Bampe_outputPE(pe, mpe[vstr[0]], ofile);
		mpe.erase(vstr[0]);
	}
	else
	{
		mpe[vstr[0]] = pe;
	}
}


inline void BamAlign2pe::Bampe_outputPE( Pair_End& pe1, Pair_End& pe2, ofstream& ofile )
{
	char		ch;
	int			nStart;
	int			nEnd;
	if(abs(pe1.npos - pe2.npos)<pe1.nrlen)
	{
		return ;
	}
	else
	{
		int		len = abs(pe1.npos-pe2.npos);
		if(pe1.npos < pe2.npos)
		{
			if(pe_checkgap(pe1.npos, pe2.npos))//true : in gap, false : not in gap
				return;
			ch = CH(m_cc[pe1.ch], m_cc[pe2.ch])+'0';
			if(!m_breverse && pe1.nmean > 1000)
			{
				ch = m_mcc[ch];
			}
			if(pe_checknormal(pe1, pe2, ch))
			{
				if(!m_bnormal)
				{
					return;
				}
			}
			int mapQP1=1;
			int mapQP2=1;
			if  (pe1.nqual>=20) { mapQP1=1 ;}
			else if  (pe1.nqual==0) { mapQP1=10 ;}
			else {mapQP1=2;}

			if  (pe2.nqual>=20) { mapQP2=1 ;}
			else if  (pe2.nqual==0) { mapQP2=10 ;}
			else {mapQP2=2;}



			ofile<<ch<<'\t'<<ch<<'\t'<<pe1.npos<<'\t'<<pe2.npos+pe2.nrlen<<'\t'<<mapQP1<<'\t'<<mapQP2<<'\t';//<<"215-13\t";
			ofile<<pe1.nmean<<'-'<<pe1.nsd<<'\t'<<pe2.npos+pe2.nrlen-pe1.npos<<'\t'<<pe1.strid<<'\t'<<m_strchr<<'\n';
		}
		else
		{
			if(pe_checkgap(pe2.npos, pe1.npos))//true : in gap, false : not in gap
				return;
			ch = CH(m_cc[pe2.ch], m_cc[pe1.ch])+'0';
			if(!m_breverse && pe1.nmean > 1000)ch = m_mcc[ch];
			if(pe_checknormal(pe2, pe1, ch))
			{
				if(!m_bnormal)
					return;
			}

			int mapQP1=1;
			int mapQP2=1;
			if  (pe1.nqual>=20) { mapQP1=1 ;}
			else if  (pe1.nqual==0) { mapQP1=10 ;}
			else {mapQP1=2;}

			if  (pe2.nqual>=20) { mapQP2=1 ;}
			else if  (pe2.nqual==0) { mapQP2=10 ;}
			else {mapQP2=2;}

			ofile<<ch<<'\t'<<ch<<'\t'<<pe2.npos<<'\t'<<pe1.npos+pe1.nrlen<<'\t'<<mapQP2<<'\t'<<mapQP1<<'\t';//<<"215-13\t";
			ofile<<pe2.nmean<<'-'<<pe2.nsd<<'\t'<<pe1.npos+pe1.nrlen-pe2.npos<<'\t'<<pe2.strid<<'\t'<<m_strchr<<'\n';
		}
	}

}

//////////////////////////////////////////////////////////////////////////
void*		 __Bamalign2_process(void*);
bool		 initInsert(const char* pfile, MInsertSD& mis);
void		 readgap(map<string, vector<SGAP> >& pgap);
//////////////////////////////////////////////////////////////////////////



//implement file: align2pe.cpp

/************************************************************************/
// mutex_s = PTHREAD_MUTEX_INITIALIZER;
// g_binsertfile = true;
/************************************************************************/

//string		g_stroutdir;
int main_Bamalign2pe(int argc, char* argv[], void* pVoid /*= NULL*/)
{
	AfxGetOptions(argc, argv);
	if (AfxGetValue("-3")!=NULL || AfxGetValue("-4")!=NULL)
		return 1;
	cout<<"Align2pe......"<<endl;

	VString*	pVstr = &(((global_param*)pVoid)->vstr);

	VString		vfilename;
	char *		pName = AfxGetValue("--i");
	if(pName == NULL)
		return 0;

	if(pVstr->size() != 0)
	{
		vfilename.insert(vfilename.end(), pVstr->begin(), pVstr->end());
		pVstr->clear();
	}
	else
	{
		Getnamefromlist(AfxGetValue("-i"), vfilename);
	}
	if (vfilename.size() == 0)
	{
		printf("No file input or exsit! Align2pe testting......\n");
		return 1;// Temporary return, for this module is not in use.
	}

	char*   pcpu = AfxGetValue("-cpu");
	int		cpu = (pcpu==NULL) ? 4 : atoi(pcpu);

	MInsertSD		minsertsd;
	if(!initInsert(AfxGetValue("-insert"), minsertsd))
	{
		cerr<<"Error : insert size info is wrong !"<<endl;
		return 0;
	}

	CThreadManager		threadMgr(cpu);
	vector<align2pe_thread_param>		vtp(vfilename.size());
	threadMgr.SetTimer(0.5);
	for (int i=0; i<(int)vfilename.size(); i++)
	{
		vtp[i].sname		= vfilename[i];
		vtp[i].pVstr		= pVstr;
		vtp[i].pinsert		= &minsertsd;
		threadMgr.AddThread(__Bamalign2_process, (void*)&vtp[i]);
	}
	//
	threadMgr.Run();

	return 1;
}

//*///
void* __Bamalign2_process(void* param)
{
	align2pe_thread_param*	pParam = (align2pe_thread_param*)param;
	BamAlign2pe		align2pe(pParam->pinsert);

	
	string			tmp;
	map<string, vector<SGAP> > mgap;
	readgap(mgap);

	align2pe.pe_readgap(pParam->sname.c_str(), &mgap);
	align2pe.pe_getinsertinfo(pParam->pinsert);

	align2pe.pe_convsoap2pe(pParam->sname.c_str(), *(pParam->pVstr));
	return NULL;
}


BamAlign2pe::BamAlign2pe()
{
	char* pq = AfxGetValue("-Q");
	m_nqual = (pq==NULL) ? 1 : atoi(pq);
	m_mcc['0'] = '3';
	m_mcc['1'] = '2';
	m_mcc['2'] = '1';
	m_mcc['3'] = '0';
	m_mcc['4'] = '4';
	m_mcc['5'] = '5';
	m_breverse = AfxGetValue("-R")==NULL?false:true;//use for test.
}

BamAlign2pe::~BamAlign2pe()
{

}

void BamAlign2pe::pe_convsoap2pe(const char* pName, VString& vstr)
{
	m_bnormal = (AfxGetValue("-normal")==NULL) ? false : true;
	MPAIREND	mpe;
	string		tmp = Formatnewfilename(pName, ".PE", AfxGetValue("-o"));

	pthread_mutex_lock(&mutex_s);
	vstr.push_back(tmp);
	pthread_mutex_unlock(&mutex_s);

	ofstream	ofile(tmp.c_str());
	string path=pName ;
	string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);

	
	TSamCtrl SAM ;
	char in_mode[5] ={ 0 };
	in_mode[0]='r';
	if (ext == "bam")
	{
		cout<<"---- read Bamfile: "<<pName<<endl;
		in_mode[1]='b';
	}
	else
	{
		cout<<"---- read Samfile: "<<pName<<endl;
	}
	
	SAM.open(pName,in_mode);

	string		str;
	//getline(gifile, str);
	SAM.readline(str) ;
	if(str.empty())return;
	if(str[0] != '>')
	{
		VString		vstr;
		split(str, vstr, "\t ");

		m_strchr = vstr[2];

		Bampe_outputPE(str, mpe, ofile);
		while (SAM.readline(str)!=-1)
		{
			Bampe_outputPE(str, mpe, ofile);
		}
	}
	else
	{
		m_strchr = str.substr(1, str.length()-1);
		while (SAM.readline(str)!=-1)
		{
			Bampe_outputPE(str, mpe, ofile);
		}
	}



	SAM.close();					
	ofile.close();
	mpe.clear();

}
void BamAlign2pe::pe_readgap( const char* p, map<string, vector<SGAP> >* pgap )
{
	if (p == NULL)
		return ;
	if (pgap->size() == 0)
		return;
	string path=p ;
	string ext =path.substr(path.rfind('.') ==string::npos ? path.length() : path.rfind('.') + 1);
    TSamCtrl *samhandleTmp = new TSamCtrl ;
	char in_mode[5] ={ 0 };
	in_mode[0]='r';
	if (ext == "bam")
	{
		in_mode[1]='b';
	}
	
	samhandleTmp->open(p,in_mode);

	string		str;
	if(samhandleTmp->readline(str)!=-1)
	{
		VString		vstr;
		split(str, vstr,"\t \n");
		char* ptype = AfxGetValue("-type");
		if(vstr[0][0] == '>')
		{
			if (ptype != NULL)
			{
				if(strcmp(ptype, "soap")==0 )
					str = vstr[0].substr(1, vstr[0].length()-1);
				else if(strcmp(ptype, "maq")==0)
					str = vstr[0].substr(1, vstr[0].length()-1);
				else return;
			}
			else
			{
				str = vstr[0].substr(1, vstr[0].length()-1);
			}
		}
		else
		{
			str = vstr[2];
		}
		m_vgap = &(pgap->operator [](str));
	}

}

bool BamAlign2pe::pe_getinsertinfo(MInsertSD* p)
{
	m_pminsert = p;
	return true;
}

#endif //_ALIGN2PE_H_
