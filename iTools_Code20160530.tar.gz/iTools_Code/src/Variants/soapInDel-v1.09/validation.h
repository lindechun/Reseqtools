/** @file validation.h
 *This is the header file of the 'validation' module
 */  
#ifndef _VALIDATION_H_
#define _VALIDATION_H_
#include <map>
#include <string>
#include <vector>
#include <iostream>
#include <fstream>
#include <sstream>
#include <algorithm>
#include "parse.h"
#include "validation.h"
#include "statistics.h"
using namespace std;

extern char soap_file[];        ///< name of the file including the list of soap result files
extern char pos_file[];         ///< name of the file including the query information
extern char valid_output_file[];///< output file of the validation result
extern char ref_file[];         ///< name of the reference file

/**
 * class for storing the target reads 
 */
class hit_reads 
{
	public:
		string type;                            ///< indel type
		long pos;                               ///< position of indel in the chromosome
		vector< pair<size_t, string> > seq_vec; ///< the target reads

		hit_reads(string &type1, long &pos1): type(type1),pos(pos1) {} ///< constructor
};

/**
 * main class of the 'validation' module
 * it has to use the class stat_base's member function
 */
class valid_t:protected stat_base
{
    map<string,map<long, hit_reads> > reads_2map;   ///< store all the target reads of all query positions
    map<string, vector<long> > pos_map;             ///< store the query information
    map<string,string> ref_map;                     ///< store the reference composed of one or more chromosomes
    
    //internal interface
    int get_pos_vec( const char *pos_file);
    int get_reads(const char *file_name);
    int write_reads(const char*output_file);
    int read_ref(char *file_name);
    
    //external ifterface
    public:
    int run_valid();

};

/** @file validation.h
 *This is the implementation  file of the 'validation' module
 */  
/**
 * check a read given whether it covers an indel in the query list, using binary search for efficiency
 */
static int bisearch(long pos, vector<long> &pos_vec, int read_len)
{
    int index;

    //when the vector's size is 1, note that 'start == end', so it is an exception 
    if (pos_vec.size() == 1 ) {
        if (pos_vec[0]  <= pos + read_len && pos_vec[0] >= pos)return 0;
        else return -1;
    }

    int start = 0;
    int end = pos_vec.size() - 1;
    int i = 0;

    while(start < end)
    {
        i++;
        index = (start + end ) / 2;
        if(pos_vec[index]  <= pos + read_len && pos_vec[index] >= pos){
            break;
        }//if remove the follow sentence, the last element in the vector would never be queried. 
        else if (pos_vec[index + 1]  <= pos + read_len && pos_vec[index + 1] >= pos){
            index++;
            break;
        }
        else
        {
            if(pos_vec[index] > pos + read_len)end = index;
            else 
            {	//consider the endless loop
                if(start == index)
                {
                    return -1;
                }
                start = index;
            }
        }
    }

    if(start >= end)return -1;

    return index;
}

/**
 * get the positions required for query
 */
int valid_t::get_pos_vec(const char *pos_file) 
{
    igzstream ifs(pos_file, ifstream::in);

    if (!ifs.good()) {
        cerr << "can not open the file: " << pos_file << endl;
        return 0;
    }

    while (!ifs.eof()) {
        string chr;
        string type;
        long pos;

        ifs >> chr >> type >> pos;
        if (chr.length() == 0)continue; 
        map<string, vector<long> >::iterator iter = pos_map.find(chr);
        map<string,map<long, hit_reads> >::iterator iter2 = reads_2map.find(chr);
        if (iter != pos_map.end()) {
            iter->second.push_back(pos);
            iter2->second.insert(pair<long, hit_reads>(pos, hit_reads(type, pos)));
        }
        else {
            vector<long> pos_vec;
            pos_vec.push_back(pos);
            pos_map.insert(pair<string, vector<long> >(chr, pos_vec));

            map<long, hit_reads> reads_map;
            reads_map.insert(pair<long, hit_reads>(pos, hit_reads(type, pos)));
            reads_2map.insert(pair<string,map<long, hit_reads> >(chr, reads_map));
        }
    }

    return 0;
}

/**
 * seach every files to get wanted reads
 */
int valid_t::get_reads( const char *file_name)
{
    //cout << "in the get_read " << endl;
    igzstream ifs ( file_name, ifstream::in );
    if (!ifs) {
        cerr << "open soap file error: " << file_name << endl;
        return 0;
    }

    int i = 0;
    while (!ifs.eof()) {
        i++;
        soap_t soapvar1;

        if (0 != soapvar1.parse_line(ifs))continue;

        //get a line every time
        string chr = soapvar1.get_chr();
        map<string, vector<long> >::iterator iterm = pos_map.find(chr);
        if (iterm == pos_map.end()) continue;

        //get start position of this read
        long pos = soapvar1.get_pos();
        int read_len = soapvar1.get_read_len();
        vector<long> &pos_vec = pos_map[chr];
        map<long, hit_reads> &reads_map = reads_2map[chr];

        //check if this read is wanted
        int index = bisearch(pos, pos_vec,  read_len);
        if (index >= 0) {
            string str = soapvar1.get_seq();
            map<long, hit_reads>::iterator iter = reads_map.find(pos_vec[index]);
            if (iter == reads_map.end()) continue;

            size_t indel_pos = pos_vec[index] - pos;
            string mm_indel = soapvar1.get_mm_indel() ;
            //+1024, its function is to distinguish the indel & non-indel reads
            if (mm_indel.length() == 3 )indel_pos += 1024;

            iter->second.seq_vec.push_back(pair<size_t, string>(indel_pos, str));
        }
    }

    ifs.close();

    return 0;
}

/** writing the target reads. 
 *it looks quite  compllex.In fact , it just wants to write the result like the following format, the first line is cut from the reference(length is 150), and the '-' character stands for 1-bp gap
 *TCAACTATTTTAATTTTCTTTTTTT-GGGGGTATTATTGTTTA
 *            ATTTTCTTTTTTTGGGGGGTATTATTGTTTA
 *            ATTTTCTTTTTTT-GGGGGTATTAT
 * 
 */
int valid_t::write_reads(const char*output_file) 
{
    ogzstream ofs(output_file, ofstream::out);
    if (!ofs.good()) {
        cerr << "can not open file : " << output_file << endl;
        return 0;
    }

    for (map<string, map<long, hit_reads> >::iterator iter1 = reads_2map.begin(); iter1 != reads_2map.end(); iter1++){
        if (iter1->first.length() == 0) continue;

        map<long, hit_reads> &reads_map = iter1->second;
        string &ref_str = ref_map[iter1->first];
        for (map<long, hit_reads>::iterator iter = reads_map.begin(); iter != reads_map.end(); iter++) {
            long pos = iter->first;
            int indel_len = (iter->second.type[1] - '0') * 10 + (iter->second.type[2] - '0');

            ofs << iter1->first << '\t' << iter->second.type << '\t' << pos << endl;
            ofs << ref_str.substr(max(0L,pos - 75 -1), 75);

            if (iter->second.type[0] == '1') {
                ofs << ref_str.substr(pos -1, min((long)ref_str.length() -pos + 1, long(75 + indel_len)));
            }
            else {
                ofs << string(indel_len, '-');
                ofs << ref_str.substr(pos -1, min((long)ref_str.length(), 75L));
            }
            ofs << ref_str.substr(pos -1,75);

            ofs << endl;

            vector< pair<size_t, string> > &seq_vec = iter->second.seq_vec;
            for(vector< pair<size_t, string> >::iterator iter2 = seq_vec.begin(); iter2 != seq_vec.end(); iter2++) {
                int flag = 0;
                int left = iter2->first;

                if (iter->second.type[0] == '1') 
                {
                    if (iter2->first >= 1024) {flag = 1; left = iter2->first -1024;}

                    ofs << string(75 - left, ' ');

                    ofs << iter2->second.substr(0, left);
                    if (flag) ofs << string(indel_len, '-');
                    ofs << iter2->second.substr(left) << endl;
                }
                else {

                    if (iter2->first < 1024) {flag = 1; }
                    else left = iter2->first -1024;
                    ofs << string(75 - left, ' ');

                    ofs << iter2->second.substr(0, left);
                    if (flag) ofs << string(indel_len, '-');
                    ofs << iter2->second.substr(left) << endl;


                }
            }		

            cout << endl;
        }
    }
    
    return 0;
}

/**
 * read in some chromsome from reference file, unwanted chromsomes skipped 
 */
int valid_t::read_ref(char *file_name)
{
    cout << "in the read_ref" << endl;
    for (map<string, vector<long> >::iterator iter = pos_map.begin(); iter != pos_map.end(); iter++) {
        map<string, long>::iterator iter1 = chr_count.find(iter->first);

        if (iter1 != chr_count.end()) {
            ref_map.insert(pair<string, string>(iter->first, string(iter1->second + 1, 0)));
        }
    }

    igzstream ifs(file_name, ifstream::in);
    if (!ifs.good()) {
        cerr << "can not open the reference file" << endl;
        return 0;
    }
    string tmpstr;
    getline(ifs, tmpstr);
    while (tmpstr.find(">") == tmpstr.npos && !ifs.eof()) getline(ifs, tmpstr);

    while (!ifs.eof())
    {
        istringstream iss(tmpstr.substr(tmpstr.find(">") + 1), istringstream::in);
        string chr;
        iss >> chr;
        //cout << "handling chr : " << chr << endl; 
        map<string, string>::iterator iter2 = ref_map.find(chr);
        if (iter2 == ref_map.end()) {
            getline(ifs, tmpstr);
            while (tmpstr.find(">") == tmpstr.npos && !ifs.eof())  getline(ifs, tmpstr);
            continue;
        }

        string::iterator iter3 = iter2->second.begin(); 
        while(!ifs.eof())
        {
            getline(ifs, tmpstr);
            if (tmpstr.find(">") != tmpstr.npos)break;

            iter3 = copy(tmpstr.begin(), tmpstr.end(), iter3);
        }
    }

    return 0;
}

/**
 * the entry of the query function
 */
int valid_t::run_valid()
{
    map<string, vector<long> > pos_map;
    map<string, map<long, hit_reads> > reads_2map;
    map<string, string> ref_map;
    
    read_file_list(soap_file);
    base_count(ref_file);
    get_pos_vec(pos_file);
    read_ref(ref_file);

    for (map<string, vector<long> >::iterator iter = pos_map.begin(); iter != pos_map.end(); iter++) {	
        //the vector must be sorted before binary search
        sort(iter->second.begin(), iter->second.end());
    }

    for (vector<string>::iterator it = file_list.begin(); it != file_list.end(); it++) {
        get_reads(it->c_str());
    }

    write_reads (valid_output_file);

    return 0;
}

#endif
