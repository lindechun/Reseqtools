/** @file evaluation.h
 *  This is the header file of the 'evaluation' module
 */
#ifndef _EVALUATION_H_
#define _EVALUATION_H_ 
#include <vector>
#include <map>
#include "parse.h"
#include "statistics.h"
#include <iostream>
#include <fstream>
#include <sstream>
#include <cmath>
#include <ctime>
#include "math_fun.h"
#include "validation.h"
#include "threadmgr.h"
#include "../../ALL/comm.h"


using namespace std;

char soap_file[1024] = "";                          ///< name of the file holding the list of soap result file
char chrinfo[1024] = "";                            ///< name of the file holding the chromosome information
char ref_file[1024] = "";                           ///< name of the reference file                                                                 
char pos_file[1024] = "";                           ///< name of the file holding the query information 
char valid_output_file[1024] = "output_reads.map";  ///< name of the result file in the 'validation' module
char result_file[1024] = "./indel-result.info";     ///< name of result file of indel-calling

int indel_offset = 5;       ///< offset to merge adjacent indels
float pri_pro = 0.5;        ///< prior probability of the heteroizygosis hypothesis
int repeat_offset = 5;      ///< used in checking if the adfacent domains are repeated regions
float p_discard = 0.05;     ///< used in calculating the lower bound and the upper bound of the depth
int mismatch_offset = 5;    ///< used in checking if the adjacent bases of the read are mismatchs
float pevent = 0.01;        ///< the minimum probability to accept the candidate indels
float sample_mult = 0;      ///< mult of the the samples which user can spacify
int min_cutoff = 3;         ///< minimum supporting reads to accept the candidate indel
size_t ncpu = 1;            ///< number of the processors to use

extern long indel_reads_cnt;    ///< count the reads with indels
extern long indel_discard_cnt;  ///< count the reads which consist indels but have been discarded

/**
 * main class of the 'evaluation' module
 */
class eval_t
{
    map<string, vector<unsigned char> > *pbpstat_vec;       ///< point to the bpstat_vec
    map<string, map<string, indel_info> > *pindel_stat_vec; ///< point to the indel_stat_vec

    public:
    explicit eval_t(stat_t *pstat_var):pbpstat_vec(&pstat_var->bpstat_vec), pindel_stat_vec(&pstat_var->indel_stat_all) {}

    int run_eval(); 

    int get_depth_bound(vector<unsigned char>  &bpstat, float percent, int &low_bnd, int &up_bnd, float &mean_dep);
    int  pdecision_cal(int mean_dep, int indel_dep, int  total_dep);  

    int offset_sub();

    int hh_bitest();

};

/** @file evaluation.cpp
 *  This is the implementation file of the 'evaluation' module
 */

/** @mainpage
 *<img src="soapindel.png" alt="Angry face"/>
 *============================================================================<br>
 *Program:SOAPindel<br>
 *Compile Date: Wed Aug  5 23:53:41 CST 2009<br>
 *Author:  BGI shenzhen<br>
 *Version: 1.08<br>
 * <br>
 *Usage:  SOAPindel [options]<br>
 *-s      str   file name of .soap/.single list(required)<br>
 *-f      str   file name of the reference file(required)<br>
 *-m      int   maximum offset of mismatch to discard reads[1]<br>
 *-p      float minimum probability to accept indel calling[0.01]<br>
 *-k      int   offset to merge flanking indels[5]<br>
 *-c      int   minimum indel-reads hits to accept indel calling[3]<br>
 *-i      str   file name of the reference's chromosome information<br>
 *-u      int   number of processors to use<br>
 *-o      str   file name of indel-calling result[./indel-result.list]<br>
 *-h      float heterozygosis indels prior probability[0.5]<br>
 *-b      float multiple of the sample,default from the soap result<br>
 *-Q      str   file name of positions to query, get the reads covering a specified position<br>
 *-O      str   output file name of query,work with '-Q'[./output_reads.map]<br>
 *=============================================================================<br>
 */
/**
 * usage printing function
 */
void print_usage()
{
	cerr << "Usage:  SOAPindel 1.09 licai@genomics.cn [options] " << endl;
	cerr << "\t-s	<str>   file name of .soap/.single list(required) " << endl;
	cerr << "\t-f	<str>	file name of the reference file(required) " << endl;
	cerr << "\t-m	<int>   maximum offset of mismatch to discard reads[1]  " << endl;
	cerr << "\t-p	<float>	minimum probability to accept indel calling[0.01] " << endl;
	cerr << "\t-k	<int>   offset to merge flanking indels[5] " << endl;
	cerr << "\t-c	<int>   minimum indel-reads hits to accept indel calling[3] " << endl;
	cerr << "\t-i	<str>	file name of the reference's chromosome information  " << endl;
	cerr << "\t-u	<int>	number of processors to use   " << endl;
	cerr << "\t-o	<str>	file name of indel-calling result[./indel-result.list] " << endl;
	cerr << "\t\t\tresult format:" << endl;
	cerr << "\t\t\tchr	position	type&size	indel-string	fr(+,-,*(+&-))   hete/homo   mean-quality indel-depth	total-depth" << endl; 
	cerr <<	"\t\t\texamle:" << endl;
	cerr << "\t\t\tchr1    1495812 D1      C       *   hete    23      6    10 " << endl;
	cerr << "\t-h	<float>	heterozygosis indels prior probability[0.5] " << endl;
	cerr << "\t-b	<float>	multiple of the sample,default from the soap result " << endl;
	cerr << "\t-Q	<str>	file name of positions to query, get the reads covering a specified position" << endl;
	cerr << "\t-O	<str>	output file name of query,work with '-Q'[./output_reads.map] " << endl;

}

/**
 * parse the program parameters
 */
int parse_cmd(int argc, char **argv)
{
	if (argc < 2) {
		print_usage();
		exit(1);
	}
	int err_flag = 0;

	for(int i = 1; i < argc; i++)
	{
		if(argv[i][0] != '-' && strlen(argv[i]) != 2){cerr << "command option error! please check." << endl;exit(1);}
		switch (argv[i][1])
		{
			case 's':
				{
					if(i + 1 == argc){cerr << "lack argument for '-s'" <<endl;err_flag = 1; break;}
					memset(soap_file, 0, sizeof(soap_file));
					memcpy(soap_file, argv[++i], sizeof(soap_file) - 1);
					break;
				}
			case 'k':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-k'" <<endl;err_flag = 1; break;}
					indel_offset = atoi(argv[++i]);
					break;
				}
			case 'm':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-m'" <<endl;err_flag = 1; break;}
					mismatch_offset = atoi(argv[++i]);
					break;
				}
			case 'c':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-c'" <<endl;err_flag = 1; break;}
					min_cutoff = atoi(argv[++i]);
					break;
				}
			case 'h':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-h'" <<endl;err_flag = 1; break;}
					pri_pro = atof(argv[++i]);

					if(pri_pro <= 0 ){cerr << "the '-h' argument less than 0" << endl;err_flag = 1;}
					break;
				}
			case 'p':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-p'" <<endl;err_flag = 1; break;}
					pevent = atof(argv[++i]);
					if(pevent <= 0 ){cerr << "the '-p' argument less than 0" << endl;err_flag = 1;}
					break;
				}
			case 'i':
				{
					if(i + 1 == argc){cerr<< "lack argument for '-i'" << endl;err_flag = 1; break;}
					memset(chrinfo, 0, sizeof(chrinfo));
					memcpy(chrinfo, argv[++i], sizeof(chrinfo) - 1);
					break;
				}
			case 'u':
				{
					if(i + 1 == argc){cerr<< "lack argument for '-u'" << endl;err_flag = 1; break;}
					ncpu = (size_t) atoi(argv[++i]);
					if (ncpu == 0) {cerr << "'-u' argument should be greater than 0" << endl;err_flag = 1;}
					break;
				}

			case 'b':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-b'" <<endl;err_flag = 1; break;}
					sample_mult = atof(argv[++i]);
					if(sample_mult <= 0 ){cerr << "'-b' argument should be greater than 0" << endl;err_flag = 1;}
					break;
				}

			case 'd':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-d'" <<endl;err_flag = 1; break;}
					p_discard = atof(argv[++i]);
					if(p_discard <= 0 ){cerr << "'-d' argument should be greater than 0" << endl;err_flag = 1;}

					break;
				}
			case 'f':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-f'" <<endl;err_flag = 1; break;}
					memset(ref_file, 0, sizeof(ref_file));
					memcpy(ref_file, argv[++i],sizeof(ref_file) - 1);
					break;
				}
			case 'o':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-o'" <<endl;err_flag = 1; break;}
					memset(result_file, 0, sizeof(result_file));
					memcpy(result_file, argv[++i],sizeof(result_file) - 1);
					break;
				}
			case 'Q':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-Q'" <<endl;err_flag = 1; break;}
					memset(pos_file, 0, sizeof(pos_file));
					memcpy(pos_file, argv[++i],sizeof(pos_file) - 1);
					break;

				}
			case 'O':
				{
					if(i + 1 >= argc){cerr << "lack argument for '-O'" <<endl;err_flag = 1; break;}
					memset(valid_output_file, 0, sizeof(valid_output_file));
					memcpy(valid_output_file, argv[++i],sizeof(valid_output_file) - 1);
					break;

				}
			default:
				{
					cerr << endl << "command options error!!!" << endl << endl;err_flag = 1;
				}
		}
	}

	if (argc == 1 ) {
		err_flag = 1;
	}

	if (err_flag) {
		print_usage();
		cerr << "command arguments error! please check." << endl; 
		exit(1);
	}
    
    string aa=valid_output_file;    aa=add_Asuffix(aa);  strcpy(valid_output_file,aa.c_str());
    aa=result_file ;  aa=add_Asuffix(aa);   strcpy(result_file,aa.c_str());

	cout << "the soap file is : " << soap_file << endl;
	cout << "indel position offset allowed is : " << indel_offset << endl;
	cout << "the mismatch_offset to discard reads : " << mismatch_offset << endl;
	cout << "the homo/hete indels prior probability :" << pri_pro << endl;
	cout << "the minimum probability of indel calling event:" << pevent << endl;

	return 0;
}

/**
 * calculate the probability of indels' correctness, it contains two parts: Possion probability for bp depth, Binomial probability for indel depth under a given bp depth.
 */
int eval_t::pdecision_cal(int mean_dep, int indel_dep, int  total_dep)
{
	if (mean_dep <= 0 || indel_dep <= 0 || total_dep <= 0) return 0;

	float p1 = 1.0;
	double p2 = 0;
	double p3 = 0; 

	//the indels depth greater than half of the total depth are considered good
	if (indel_dep / (float)total_dep < 0.5) {
		for (int i =0 ; i<= total_dep; i++) p2 += p_poisson(mean_dep, i);

		if (mean_dep < total_dep) p2 = 1 - p2;

		for (int i = 0; i <= indel_dep; i++)p3 += C_calc(i, total_dep) * pow(double(pri_pro), double(i)) * pow(double(1.0 - pri_pro), double(total_dep - i));

		p1 = p2 * p3;

	}

	if (p1 < pevent) {
		return 0;
	}

	return 1;
}

/**
 * get the boundary of every chromosome
 */
int eval_t::get_depth_bound(vector<unsigned char>  &bpstat, float percent, int &low_bnd, int &up_bnd, float &mean_dep)
{
	low_bnd = up_bnd = 0;

	if (bpstat.size() == 0) return -1;

	unsigned long total_cnt = 0;

	vector<unsigned long> count_vec(256, 0);

	for( vector<unsigned char>::iterator iter = bpstat.begin(); iter != bpstat.end(); iter++) {
		if (*iter == 0) continue;
		total_cnt++;
		count_vec[*iter & 0x7f]++; //7 bits to store the count
		//nnbp_cnt++;
	}
	//cout << "the total count is " << total_cnt << endl;

	//calculate the mean depth
	double total_size = 0;
	long nnbp_cnt = 0;
	for(size_t i = 0; i < count_vec.size(); i++) {
		total_size += i * count_vec[i];
		nnbp_cnt += count_vec[i];
	}

	//cout << total_size << '\t' << nnbp_cnt << '\t' << total_cnt << '\t' << bpstat.size() << endl;

	mean_dep = total_size / nnbp_cnt; 

	//get the boundary on two edges with the argument percent 
	unsigned long accum_count = 0;
	size_t i;
	for(i = 0; i < count_vec.size(); i++) {
		accum_count += count_vec[i];
		if (accum_count / (float)total_cnt > percent) break;
	}
	low_bnd = i;

	i++;
	while(i < count_vec.size()) {
		accum_count += count_vec[i++];

		if ((accum_count / (float)total_cnt) > (1 - percent)) break;
	}
	up_bnd = i;

	return 0;
}
/**
 * case insensitive string comparing
 */
static int istrcmp(string str1, string str2)
{
	if (str1.length() != str2.length()) return -1;

	for (size_t i = 0; i < str1.length(); i++) {
		if (toupper(str1[i]) != toupper(str2[i])) return -1;
	}

	return 0;
}
/**
 * merge the adjacent indels if they are calling a same indel
 * example:
 * ref:          ACGACACACGTGG
 * indel1:       ACGACAC--GTGG
 * indel2:       ACGA--CACGTGG
 * indel3:       ACGAC--ACGTGG
 * the three candidate indels are all possible to happen, but they are called mostly because of only  one indel, so they should be merged together.
 * the implementation is comparatively complex, because we don't want to read in all the reference in the memory.
 */
int eval_t::offset_sub()
{
	igzstream ifs(ref_file, ifstream::in);
	if (!ifs.good()) {
		cerr << "can not open reference file " << endl;
        return 0;
	}

	map<string, map<string, indel_info> > &indel_stat_vec = *pindel_stat_vec;

	for (size_t i = 0; i < indel_stat_vec.size(); i++) {
		unsigned long bp_cnt = 1;

		//handle one chromosome each time
		string tmpstr;
		getline(ifs, tmpstr);
		while (tmpstr.find(">") == tmpstr.npos && !ifs.eof())  getline(ifs, tmpstr);
		if (ifs.eof() || tmpstr.find(">") == tmpstr.npos){ifs.close(); return 0;}

		istringstream iss(tmpstr.substr(tmpstr.find(">") + 1), istringstream::in);
		string chr;
		iss >> chr;
		cout << "merging indels of : " << chr << endl; 

		map<string, indel_info>::iterator iter = indel_stat_vec[chr].begin();
		if (!ifs.eof()) getline(ifs, tmpstr);
		for (; iter != indel_stat_vec[chr].end();) {
			//hold the earlier indel, to compare with the latter
			map<string, indel_info>::iterator iter1 = iter;

			while((++iter) != indel_stat_vec[chr].end() ) {
				size_t diff = iter->second.pos - iter1->second.pos;

				if(diff > size_t(2 * indel_offset) ||  iter1->second.type != iter->second.type || iter->second.size != iter1->second.size) break;

				if (iter1->second.pos < bp_cnt) {
					continue;
				}

				if (iter->second.type == string("del")) diff += iter->second.size;
				//go to the start position
				while (iter1->second.pos > tmpstr.length() + bp_cnt) {
					bp_cnt += tmpstr.length();
					if (!ifs.eof()) getline(ifs, tmpstr);
					else { cout << "pos error" << endl;ifs.close(); return -1; }
				}

				size_t start_pos = iter1->second.pos - bp_cnt;
				string str1;
				//cut the string between two indels, storing in 'str1'
				if (tmpstr.length() - start_pos >diff) {
					str1 = tmpstr.substr(start_pos, diff);
				}
				else {
					str1 = tmpstr.substr(start_pos) ;

					bp_cnt += tmpstr.length();
					int read_cnt = diff - (tmpstr.length() - start_pos);
					getline(ifs, tmpstr);
					while (read_cnt > (int)tmpstr.length()) {
						str1 += tmpstr;
						bp_cnt += tmpstr.length();
						read_cnt -= tmpstr.length();					 

						if(!ifs.eof())getline(ifs, tmpstr);
						else {cout << "pos error2" << endl; ifs.close(); return -1;}
					}
					if (read_cnt > 0) str1 += tmpstr.substr(0, read_cnt);
				}
				//check if the two indels are one indel in fact
				string str2, str3;
				if (iter->second.type == string("ins")) {
					str2 = iter1->second.indel_str + str1;
					str3 =  str1 + iter->second.indel_str;
				}
				else {
					str2 = str1.substr(iter1->second.size);
					str3 = str1.substr(0,str1.length() - iter1->second.size);
				}
				//if same indel, then merge 
				if (!istrcmp(str2, str3)){
					iter1->second.count += iter->second.count;
					indel_stat_vec[chr].erase(iter);
					iter = iter1;
				}
			}
		}

	}

	ifs.close();
	return 0;
}

/**
 * homo/hete decision, using binomial test
 */
int eval_t::hh_bitest()
{
	map<string, map<string, indel_info> > &indel_stat_vec = *pindel_stat_vec;
	map<string, vector<unsigned char> > &bpstat_vec = *pbpstat_vec;

	for(map<string, map<string, indel_info> >::iterator iter1 = indel_stat_vec.begin(); iter1 !=  indel_stat_vec.end(); iter1++) {

		string chr(iter1->first);
		for( map<string, indel_info>::iterator iter = iter1->second.begin();
				iter != iter1->second.end(); iter++) {
			//if the region which the indel is located in is repeat region, discard the indel
			size_t irepeat;
			for (irepeat = max(int(iter->second.pos) - repeat_offset, 0); irepeat < min(bpstat_vec[chr].size(), (size_t)iter->second.pos + repeat_offset); irepeat++ ) {
				if(bpstat_vec[chr][irepeat] > 128)break;
			}

			if (irepeat < iter->second.pos + repeat_offset) {
				iter->second.count = 0;
				//////////
				cerr << "discarded for repeat" << endl;
				iter->second.dep = bpstat_vec[chr][iter->second.pos] & 0x7f;
				continue;
			}

			size_t hits_sum = bpstat_vec[chr][iter->second.pos] & 0x7f;
			iter->second.dep = hits_sum; 

			float p_val = 0;
			p_val = binomial_test(pri_pro, iter->second.count, hits_sum);
			//rough binomial test, with significance value 0.5
			if (p_val < 0.5 && (iter->second.count / (float)hits_sum > 0.5) ) {
				iter->second.pair_type = string("homo");
			}
			else {
				iter->second.pair_type = string("hete");
			}
		}
	}

	return 0;
}

/**
 * entry of the 'evaluation' module 
 * evaluate the indels mainly base on indel-depth and bp-depth  
 */
int eval_t::run_eval()
{
	map<string, vector<unsigned char> > &bpstat_vec = *pbpstat_vec;
	map<string, map<string, indel_info> > &indel_stat_vec = *pindel_stat_vec;
	//merge the adjacent candidate indels if they are calling the same indel 
	cout << "before offset_sub" << endl;
	offset_sub();
	cout << "after offset_sub" << endl;

	//homo/hete roughly estimate
	cout << "before hh_bitest" << endl;
	hh_bitest();
	cout << "after hh_bitest" << endl;

    ogzstream res_ofs(result_file, ofstream::out);
	if (!res_ofs.good()) {
		cerr << "can not open the result file" << endl;
		exit(1);
	}

	unsigned long total_cnt = 0;
	for ( map<string, vector<unsigned char> >::iterator iter1 = bpstat_vec.begin(); iter1 != bpstat_vec.end(); iter1++) {
		if (iter1->second.size() == 0) continue;
		int low_bnd = 0;
		int up_bnd = 0;
		float mean_dep;

		//calculate the boundary with a cutoff argument p_discard 
		get_depth_bound(iter1->second, p_discard, low_bnd, up_bnd, mean_dep );
		cerr << "lower bound: " << low_bnd << endl;
		cerr << "upper bound: " << up_bnd << endl;
		cerr << "mean depth: " << mean_dep << endl;

		//set the mult of sample if user has specified
		if (sample_mult >= 0.001)mean_dep = sample_mult;

		map<string, indel_info> &indel_map = indel_stat_vec[iter1->first];

		cout << iter1->first << " indel count:" << indel_map.size() << endl;

		//calculate the probability of the indel-depth/bp-depth event 
		for( map<string, indel_info>::iterator iter = indel_map.begin(); iter != indel_map.end(); iter++) {

			//if ((int)iter->second.dep < low_bnd || (int)iter->second.dep > up_bnd || iter->second.count < min_cutoff) continue;
			//if(! pdecision_cal(int(mean_dep + 0.5), iter->second.count, iter->second.dep) )continue;
            if (iter->second.pair_type.empty()){ continue ;}
			iter->second.print_indel_info(res_ofs);
			total_cnt++;
		}
	}

	res_ofs.close();

	cout << "the number of indels is : " << total_cnt << endl;

	return 0;

}

/**
 * programme entry
 */
int Var_SOAPIndel_main(int argc, char **argv)    
//int main(int argc, char **argv)
{
	parse_cmd(argc, argv);

	//this branch is for query(or validation) function
	if (strlen(pos_file) != 0) {
		valid_t valid_var;
		valid_var.run_valid();
		return 0;
	}

	clock_t start_time = clock();
	clock_t end_time; 

	stat_t stat_var;
	stat_var.run_stat();

	eval_t eval_var(&stat_var);
	eval_var.run_eval();

	end_time = clock();
	cout << "time elapsed : " << (end_time - start_time) / (float)CLOCKS_PER_SEC << endl;

	return 0;
}


#endif

