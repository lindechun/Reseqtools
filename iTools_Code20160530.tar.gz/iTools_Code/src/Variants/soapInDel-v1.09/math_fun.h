#ifndef _MATH_FUN_H_
#define _MATH_FUN_H_

#include <cmath>
#include <algorithm>
#include <iostream>

using namespace std;

float binomial_test(float p0, int x, int n);

double fact(double n);

double C_calc(double x , double n);

double p_poisson(int lamda, int x);
double p_poisson(float lamda, int x);
double p_poisson(double lamda, int x);

template <typename Iter, typename ValueType> double sd_calc(Iter start, Iter end, ValueType & mean_val)
{
    double sum = 0;
    size_t cnt = 0;
    for (Iter it = start; it != end; it++) {
        sum += (*it - mean_val) * (*it - mean_val);
        cnt++;
    }

    return sqrt(sum / (cnt - 1));
}


//binomial test 
float binomial_test(float p0, int x, int n)
{
    float  p_val = 0;
    float p = x / (float)n;

    float q0 = 1 - p0;
    if(p < p0)
    {
        for(int i = 0; i <= x; i++)
            p_val += (float)C_calc(i,n) * pow(p0, (float)i) * pow(q0, (float)(n -i));
    }
    else
    {
        for(int i = x; i <= n; i++)
            p_val += (float)C_calc(i,n) * pow(p0, (float)i) * pow(q0, (float)(n -i));

    }

    p_val = min(2 * p_val, 1.0f);

    return p_val;
}


double C_calc(double x , double n)
{
    double devisor = 1;
    double devidend = 1;

    if(x > n/2)x = n - x;

    for (double i = 0; i < x; i++)devidend *= (n -i);

    for (double i = 2; i <=x; i++)devisor *= i;

    return devidend / devisor;
}

double fact(double n)
{
    double ret = 1;
    for(double i = 1; i <= n; i++) ret *= i;

    return ret;
}

double p_poisson(double lamda, int x)
{
    return exp(double(-lamda)) * pow((double)lamda, (double)x) / fact(x);
}
double p_poisson(float lamda, int x)
{
    return exp(double(-lamda)) * pow((double)lamda, (double)x) / fact(x);
}
double p_poisson(int lamda, int x)
{
    return exp(double(-lamda)) * pow((double)lamda, (double)x) / fact(x);
}

#endif //_MATH_FUN_H_
