#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"
#include "../ALL/DataClass.h"

//KSEQ_AINIT(gzFile, gzread)

using namespace std;
typedef long long  llong ;

int  print_AddHeaderusage()
{
	cout <<""
		"\n"
		"\tUsage: AddHeader -InSam <in.sam> -Dict <ref.SamHeader> -OutSam <out.sam> \n"
		"\n"
		"\t\t-InSam     <str>   Input Sam to add SamHeader\n"
		"\t\t-Dict      <str>   Input Sam Head file\n"
		"\t\t-OutSam    <str>   Output Sam file with header\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_AddHeaderCmd(int argc, char **argv , In3str1v * para_A1 )
{
	if (argc <=2 ) {print_AddHeaderusage();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InSam" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A1->InStr1=argv[i];
		}
		else if (flag  ==  "OutSam")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A1->InStr3=argv[i];
		}
		else if (flag  ==  "Dict")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_A1->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_AddHeaderusage();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_A1->InStr1).empty() || (para_A1->InStr3).empty() || (para_A1->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para_A1->InStr3)=add_Asuffix ( (para_A1->InStr3) );

	return 1 ;
}


int Xam_SamHeader_main(int argc, char *argv[])
{
	In3str1v * para_A1 = new In3str1v;
	if( parse_AddHeaderCmd(argc, argv, para_A1 )==0)
	{
		delete  para_A1 ;
		return 0;
	}
	ogzstream OUT ((para_A1->InStr3).c_str());
	Write_Sam_head ( (para_A1->InStr2) , OUT );
	Write_Sam_head ( (para_A1->InStr1) , OUT );

	OUT.close();
	delete para_A1 ;

	return 0;

}

///////// swimming in the sky and flying in the sea ////////////
