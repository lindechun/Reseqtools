#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/gzstream/gzstream.h"

#include "../include/zlib/zlib.h"
#include <stdio.h>
//KSEQ_AINIT(gzFile, gzread)
#include "../ALL/comm.h"
#include "../Soap/Soap_RmDup.h"

using namespace std;

int  print_Ausage_Xam03()
{
	cout <<""
		"\n"
		"\tUsage: rmdup  -InBam <in.sort.bam> -output <out.sam>\n"
		"\n"
		"\t\t-InBam     <str>   Input SortBam file\n"
		"\t\t-InSam     <str>   Input SortSam file\n"
		"\t\t-OutPut    <str>   Output Sam file with rmdup\n"
		"\n"
		"\t\t-IDFlag    <int>   Add Flag to ReadID\n"
		"\t\t-SamNoHead         if the file is Sam with NoHead\n"
		"\t\t-Dict      <str>   Input Sam Head file\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_Acmd_Xam03(int argc, char **argv , In3str1v * para_Xam02  )
{
	if (argc <=2 ) {print_Ausage_Xam03();return 0 ;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0 ;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InSam" )
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ; }
			i++;
			para_Xam02->InStr1=argv[i];
		}           
		else if (flag  ==  "InBam")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_Xam02->InStr2=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			para_Xam02->InStr3=argv[i];
		}
		else if (flag  ==  "Dict")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0 ;}
			i++;
			string AA=argv[i] ;
			(para_Xam02->List).push_back(AA);
		}
		else if (flag  ==  "IDFlag")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0 ;}
			i++;
			para_Xam02->InInt=atoi(argv[i]);
		}
		else if (flag  == "SamNoHead" )
		{
			(para_Xam02->TF2)=false ;
		}
		else if (flag  == "help")
		{
			print_Ausage_Xam03();return 0 ;;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0 ;
		}
	}
	if ((para_Xam02->InStr3).empty() || ( (para_Xam02->InStr1).empty() && (para_Xam02->InStr2).empty() ) )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0 ;
	}
	(para_Xam02->InStr3)=add_Asuffix ( (para_Xam02->InStr3) );
	if ((para_Xam02->InStr1) == (para_Xam02->InStr3) )
	{
		cerr<<"\t\toutput should be not the same with the input file\n";
		return 0 ;
	}
	return 1 ;
}

int Xam_RmDup_main(int argc, char *argv[])
{

	In3str1v * para_Xam02 = new In3str1v;
	if (parse_Acmd_Xam03(argc, argv , para_Xam02 ) == 0 ) 
	{
		delete para_Xam02 ;
		return 0 ;
	}
	map <string, string> SameStat ;
	map <string, string> SameStatV2 ;

	ogzstream OUT ((para_Xam02->InStr3).c_str());
	if(!OUT.good())
	{
		cerr << "open InputFile error: "<<(para_Xam02->InStr3)<<endl;
		return 1;
	}
	if (!(para_Xam02->List).empty())
	{
		Write_Sam_head ((para_Xam02->List)[0], OUT) ;         
	}

	char in_mode[5] ={ 0 };
	in_mode[0]='r';

	if ((para_Xam02->TF2))
	{
		TSamCtrl SAM;
		if (!(para_Xam02->InStr1).empty())
		{
			SAM.open((para_Xam02->InStr1).c_str(),in_mode);
		}
		else
		{
			in_mode[1]='b';
			SAM.open((para_Xam02->InStr2).c_str(),in_mode);
		}
		int Flag =0 ,ReadLeng , hit ;
		string  lineF  ;
		//  char * RID ;
		string  RID ,seq , Qseq ,ab , zf, chr , Posi ;
		//long long Posi ;
		while(SAM.readline(lineF)!=-1)
		{
			lineF = Talignment_format(lineF);
			if (lineF.compare(NOUSE_ALIGNMENT)==0)
			{
				continue;
			}
			else
			{
				break ;
			}
		}
		istringstream isone (lineF,istringstream::in);
		isone>>RID>>seq>>Qseq>>hit>>ab>>ReadLeng>>zf>>chr>>Posi ;
		string GenoPosi=chr+Posi ;
		string NowID= RID ;
		string line ;
		while(SAM.readline(line)!=-1)
		{
			istringstream isone (line,istringstream::in);
			//A2705#GGCTAC   163    chromosome1   18    29    53S20M17S    =      248     31 
			isone>>RID>>zf>>chr>>Posi ;
			string GenoPositmp=chr+Posi ;
			if (GenoPosi!=GenoPositmp)
			{
				if (Flag)
				{
					string StortID =getID(NowID) ;
					InsertMap ( SameStat ,SameStatV2  ,StortID , GenoPosi );
					Flag=0;
				}
				NowID=RID ;
				GenoPosi=GenoPositmp;
			}
			else
			{
				string StortID =getID(NowID) ;
				InsertMap ( SameStat ,SameStatV2 , StortID , GenoPosi );
				Flag=1;
				NowID=RID ;
				GenoPosi=GenoPositmp;
			}
		}
		SAM.close();
	}
	else
	{
		igzstream IN ((para_Xam02->InStr1).c_str(),ifstream::in);
		if (IN.fail())
		{
			cerr<<"can't open file"<<endl;
			return 0 ;
		}
		string lineF; 
		int Flag =0 ;
		string RID,SamFlag,chr,Posi ;
		getline(IN,lineF);
		istringstream isone (lineF,istringstream::in);
		isone>>RID>>SamFlag>>chr>>Posi ;
		string GenoPosi=chr+Posi ;
		string NowID= RID ;

		while(!IN.eof())
		{
			string  line ,chr ,tmp;
			getline(IN,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			isone>>RID>>SamFlag>>chr>>Posi ;
			string GenoPositmp=chr+Posi ;
			if (GenoPosi!=GenoPositmp)
			{
				if (Flag)
				{
					string StortID =getID(NowID) ;
					InsertMap ( SameStat ,SameStatV2  ,StortID , GenoPosi );
					Flag=0;
				}
				NowID=RID ;
				GenoPosi=GenoPositmp;
			}
			else
			{
				string StortID =getID(NowID) ;
				InsertMap ( SameStat ,SameStatV2 , StortID , GenoPosi );
				Flag=1;
				NowID=RID ;
				GenoPosi=GenoPositmp;
			}
		}
		IN.close();
	}
	map <string, int> IDMap ;
	map <string, int> IntMap ; 

	map <string, string> :: iterator it=SameStatV2.begin();
	map <string, string> :: iterator itA ;

	for(it=SameStatV2.begin() ; it!=SameStatV2.end(); it++)
	{
		string valuB=(it->second);
		string keynow=it->first ;
		itA=SameStat.find(keynow);
		string valuA=(itA->second);
		string key=valuA+valuB;
		if (valuB<valuA)
		{
			key=valuB+valuA;
		}
		map <string, int> :: iterator itInt=IntMap.find(key);
		if (itInt==IntMap.end())
		{
			IntMap.insert(map <string, int> :: value_type(key,1));
			//      IDMap.insert(map <string, int> :: value_type(key,keynow));
		}
		else
		{
			(itInt->second)++;
			IDMap.insert(map <string, int> :: value_type (keynow,1));
			//cerr<<keynow<<"\t"<<valuA<<"\t"<<valuB<<endl;
		}
	}

	IntMap.clear();
	SameStat.clear();
	SameStatV2.clear();

	string  RID ;

	if ((para_Xam02->TF2))
	{
		TSamCtrl SAMS;
		if (!(para_Xam02->InStr1).empty())
		{
			SAMS.open((para_Xam02->InStr1).c_str(),in_mode);
		}
		else
		{
			in_mode[1]='b';
			SAMS.open((para_Xam02->InStr2).c_str(),in_mode);
		}
		if ((para_Xam02->InInt)<1)
		{

			string  line ;
			while(SAMS.readline(line)!=-1)
			{ 
				istringstream isone (line,istringstream::in);
				isone>>RID;
				string StortID =getID(RID) ;
				map <string, int> :: iterator it=IDMap.find(StortID);
				if (it==IDMap.end())
				{
					OUT<<line<<endl;
				}
			}
		}
		else
		{
			string  line ;
			while(SAMS.readline(line)!=-1)
			{        
				istringstream isone (line,istringstream::in);
				isone>>RID;
				string StortID =getID(RID) ;
				map <string, int> :: iterator it=IDMap.find(StortID);
				if (it==IDMap.end())
				{
					OUT<<(para_Xam02->InInt)<<"-"<<line<<endl;
				}
			}
		}
		SAMS.close();
	}
	else
	{
		igzstream INS ((para_Xam02->InStr1).c_str(),ifstream::in);
		if (INS.fail())
		{
			cerr<<"can't open file"<<endl;
		}

		if ((para_Xam02->InInt)<1)
		{
			while(!INS.eof())
			{
				string  line ;
				getline(INS,line);
				if (line.length()<=0)  { continue  ; }
				istringstream isone (line,istringstream::in);
				isone>>RID;
				string StortID =getID(RID) ;
				map <string, int> :: iterator it=IDMap.find(StortID);
				if (it==IDMap.end())
				{
					OUT<<line<<endl;
				}
			}
		}
		else
		{
			while(!INS.eof())
			{
				string  line ;
				getline(INS,line);
				if (line.length()<=0)  { continue  ; }
				istringstream isone (line,istringstream::in);
				isone>>RID;
				string StortID =getID(RID) ;
				map <string, int> :: iterator it=IDMap.find(StortID);
				if (it==IDMap.end())
				{
					OUT<<(para_Xam02->InInt)<<"-"<<line<<endl;
				}
			}
		}
		INS.close();
	}

	IDMap.clear();
	OUT.close();
	delete para_Xam02 ;
	return 1;
}


///////// swimming in the sky and flying in the sea ////////////
//




