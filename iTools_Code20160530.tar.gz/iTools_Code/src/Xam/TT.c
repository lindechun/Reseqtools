#include <stdio.h>
#include "../sam/sam.h"
#include "../sam/kstring.h"

int main(int argc, char *argv[]){
	bamFile fp = bam_open(argv[1], "r");
	bam1_t *b = bam_init1();
	bam_header_t *h;
	h = bam_header_read(fp);
	while(bam_read1(fp, b)>=0){
		uint32_t *cigar = bam1_cigar(b);
		const bam1_core_t *c = &b->core;
		int i, l;
		kstring_t str;
		str.l = str.m = 0; str.s = 0;
		if (b->core.tid < 0) return 0;
		for (i = l = 0; i < c->n_cigar; ++i) {
			int op = cigar[i]&0xf;
			if (op == BAM_CMATCH || op == BAM_CDEL || op == BAM_CREF_SKIP)
				l += cigar[i]>>4;
		}
		if (c->n_cigar == 0) kputc('*', &str);
		else {
			for (i = 0; i < c->n_cigar; ++i) {
				kputw(bam1_cigar(b)[i]>>BAM_CIGAR_SHIFT, &str);
				kputc("MIDNSHP=X"[bam1_cigar(b)[i]&BAM_CIGAR_MASK], &str);
			}                                                                    
		}
		printf("%s\n",str.s);
		printf("%s\t%d\n",h->target_name[c->tid],h->target_len[c->tid]);
		printf("%s\t%d\t%d\t%s\t%d\t%c\t%c\t%c\n", bam1_qname(b),c->pos, c->pos + l, bam1_qname(b), c->qual, (c->flag&BAM_FREVERSE)? '-' : '+',bam_nt16_rev_table[bam1_seqi(bam1_seq(b),0)],bam1_qual(b)[0]+33);
	}
	return 0;
}
