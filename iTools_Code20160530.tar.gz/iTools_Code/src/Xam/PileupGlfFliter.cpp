#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
using namespace std;

///////////////////
string &  replace_all(string &  str,const   string&  old_value,const string&   new_value)      
{      
	while(true)   {      
		string::size_type   pos(0);      
		if(   (pos=str.find(old_value))!=string::npos   )      
			str.replace(pos,old_value.length(),new_value);      
		else   break;      
	}      
	return   str;      
}      

string &   replace_all_distinct(string&   str,const   string&   old_value,const   string&   new_value)      
{      
	for(string::size_type   pos(0);   pos!=string::npos;   pos+=new_value.length())   {      
		if(   (pos=str.find(old_value,pos))!=string::npos   )      
			str.replace(pos,old_value.length(),new_value);      
		else   break;      
	}      
	return   str;      
}      
void split(const string& str,vector<string>& tokens,  const string& delimiters = " ")
{
	string::size_type lastPos = str.find_first_not_of(delimiters, 0);
	string::size_type pos     = str.find_first_of(delimiters, lastPos);
	while (string::npos != pos || string::npos != lastPos)
	{
		tokens.push_back(str.substr(lastPos, pos - lastPos));
		lastPos = str.find_first_not_of(delimiters, pos);
		pos = str.find_first_of(delimiters, lastPos);
	}
}
///////////////////



int main(int argc,char *argv[])
{

	if(argc!=3)
	{
		cout<<"\tVersion 1.0\thewm@genomics.org.cn\t2011-08-29\n";
		cout<<argv[0]<<"\tInPut\tOutPut"<<endl;
		return 1 ;
	}
	string OutFile=argv[2] ;
	string::size_type pos = OutFile.rfind('.');
	string ext = OutFile.substr(pos == string::npos ? OutFile.length():pos + 1);
	if (ext != "gz" ) {OutFile=OutFile+".gz" ; }

	ogzstream OUT (OutFile.c_str());
	string InputFile=argv[1] ;
	igzstream IN (InputFile.c_str(),ifstream::in); // igzstream 

	if(!OUT.good())
	{
		cerr << "open OutFile error: "<<OutFile<<endl;
		return 1;
	}
	if(!IN.good())
	{
		cerr << "open InputFile error: "<<InputFile<<endl;
		return 1;
	}
	////////////////////////swimming in the sea & flying in the sky //////////////////   
	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if (line.length()<=0)  { continue  ; }
		istringstream isone (line,istringstream::in);
		string chr ,posi, type; 
		isone>>chr>>posi>>type;
		if ( type == "*" )
		{
			continue  ;
		}
		OUT<<line<<endl;
	}
	IN.close();
	OUT.close();
	return 0 ;
}
////////////////////////swimming in the sea & flying in the sky //////////////////


