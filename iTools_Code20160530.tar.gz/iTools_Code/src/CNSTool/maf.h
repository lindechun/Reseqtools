#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"

using namespace std;
typedef long long llong ;


int  print_usage_10()
{
	cout <<""
		"\n"
		"\tUsage: MAF -InFile <in.raw> -OutPut <out.maf>\n"
		"\n"
		"\t\t-InFile   <str>   Input raw or the addcn file\n"
		"\t\t-InList   <str>   Input raw or the addcn list file\n"
		"\t\t-OutPut   <str>   OutPut Minor Allele Frequency file\n"
		"\n"
		"\t\t-help             show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_10(int argc, char **argv,  In3str1v * para_10)
{
	if (argc <=2 ) {print_usage_10();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InFile" )
		{
			if(i + 1 == argc) { LogLackArg( flag ) ; return 0;}
			i++;
			para_10->InStr1=argv[i];
			para_10->InInt=2;
		} 
		else if (flag  == "InList" )
		{
			if(i + 1 == argc){ LogLackArg( flag ) ;return 0;}
			i++;
			para_10->InStr2=argv[i];
			para_10->InInt=3;
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) { LogLackArg( flag ) ;return 0;}
			i++;
			para_10->InStr3=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_10();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_10->InStr3).empty()  ||  (para_10->InInt)==0)
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(para_10->InStr3)=add_Asuffix((para_10->InStr3));
	return 1 ;
}


int Maf_main(int argc,char *argv[])
{
	In3str1v * para_10 = new In3str1v;
	if (parse_cmd_10(argc, argv, para_10 )==0)
	{
		delete  para_10 ;
		return  0;
	}

	ogzstream  OUT ((para_10->InStr3).c_str());

	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<para_10->InStr3<<endl;
		delete  para_10 ;
		return 1;
	}

	map <llong,llong> maf ;
	if ( (para_10->InInt)==2)
	{
		igzstream IN (para_10->InStr1.c_str(),ifstream::in); // igzstream 
		if(!IN.good())
		{
			cerr << "open InputFile error: "<<para_10->InStr1<<endl;
			return 1;
		}
		string temp ; 
		llong base1 ,base2 ;
		////////////////////////swimming in the sea & flying in the sky //////////////////   
		while(!IN.eof())
		{
			string  line ;
			getline(IN,line);
			if (line.length()<=0)  { continue  ; }
			istringstream isone (line,istringstream::in);
			isone>>temp>>temp>>temp>>temp>>temp>>temp>>temp>>base1>>base2 ; 
			if (base1<base2)
			{
				base2=base1 ;
			}
			maf[base2]++ ;
		}
		IN.close();
	}
	else if ((para_10->InInt)==3)
	{
		vector <string>  Soap_Stat  ;
		ReadList (para_10->InStr2,Soap_Stat ) ;
		int Soap_Stat_count=Soap_Stat.size();
		for (int i=0; i<Soap_Stat_count ; i++)
		{
			string SoapStat_Now=Soap_Stat[i];
			igzstream IN_SOAP (SoapStat_Now.c_str(),ifstream::in); // igzstream
			if(!IN_SOAP.good())
			{
				cerr << "open InputFile error: "<<SoapStat_Now<<endl;
				return 1;
			}
			string temp ; 
			llong base1 ,base2 ;
			while(!IN_SOAP.eof())
			{
				string  line ;
				getline(IN_SOAP,line);
				if (line.length()<=0)  { continue  ; }
				istringstream isone (line,istringstream::in);
				isone>>temp>>temp>>temp>>temp>>temp>>temp>>temp>>base1>>base2 ; 
				if (base1<base2)
				{
					base2=base1 ;
				}
				maf[base2]++ ;
			}
			IN_SOAP.close();
			IN_SOAP.clear();
		}
	}
	OUT<<"#Allele\tNumber"<<endl;
	map <llong,llong> ::iterator map_it =maf.begin();
	while(map_it!=maf.end())
	{
		OUT<<map_it->first<<"\t"<<map_it->second<<endl ;
		map_it++ ;
	}
	OUT.close();
	delete para_10 ;
	return 0 ;
}
////////////////////////swimming in the sea & flying in the sky //////////////////


///////// swimming in the sky and flying in the sea ////////////
