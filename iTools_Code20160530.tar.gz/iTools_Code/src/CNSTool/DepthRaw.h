#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "glfRead.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"

using namespace std;

int  print_usage_9()
{
	cout <<""
		"\n"
		"\tUsage: DepthRaw -InPut <in.raw> -OutPut <out.depth>\n"
		"\n"
		"\t\t-InPut     <str>   InPut raw or the addcn  file\n"
		"\t\t-OutPut    <str>   OutPut of the depth[4 row] dis\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}

int parse_cmd_9(int argc, char **argv, In3str1v * para_9 )
{
	if (argc <=2 ) {print_usage_9();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "InPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_9->InStr1=argv[i];
		}
		else if (flag  ==  "OutPut")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_9->InStr2=argv[i];
		}
		else if (flag  == "help")
		{
			print_usage_9();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_9->InStr1).empty() ||  (para_9->InStr2).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}

//programme entry
///////// swimming in the sky and flying in the sea ////////////
int depthraw_main(int argc, char **argv)
{
	In3str1v * para_9 = new In3str1v;
	if (parse_cmd_9(argc, argv,  para_9 )==0 )
	{
		delete para_9 ;
		return 0 ;
	}
	igzstream IN (para_9->InStr1.c_str(),ifstream::in); // ifstream  + gz 
	ofstream  OUT (para_9->InStr2.c_str());

	if(!IN.good())
	{
		cerr << "open IN File error: "<<para_9->InStr1<<endl;
		return 0;
	}
	if(!OUT.good())
	{
		cerr << "open OUT File error: "<<para_9->InStr2<<endl;
		return 0;
	} 

	map <int,long> maf_stat ;
	while(!IN.eof())
	{
		string  line ;
		getline(IN,line);
		if (line.length()<=0)  { continue ; }

		vector<string> inf;
		split(line,inf," \t" );
		int A=atoi(inf[3].c_str()) ;
		maf_stat[A]++;
	}

	OUT<<"##Depth\tNumber"<<endl;
	map  <int,long> ::const_iterator map_it=maf_stat.begin();
	while(map_it!=maf_stat.end())
	{
		OUT<<map_it->first<<"\t"<<map_it->second<<endl;
		map_it++;
	}

	IN.close();
	OUT.close();
	delete para_9 ;
	return 0;
}

///////// swimming in the sky and flying in the sea ////////////
