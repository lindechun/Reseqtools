/*
 * DataClass.h
 *
 *  Created on: 2011-11-21
 *      Author: hewm@genomics.org.cn
 */

#ifndef Ex_H_
#define Ex_H_

#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <map>
#include <vector>
#include <cmath>
#include <cassert>
#include <cstdlib>
#include "../ALL/DataClass.h"
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/comm.h"
#include "../File/FileSF.h"

using namespace std;

int  print_Usage_Ex()
{
	cout <<""
		"\n"
		"\tUsage:   -InSite <in.SNP> -InALL <all.raw> -OutPut <output>\n"
		"\n"
		"\t\t-InSite    <str>   Input the Site File(chr posi)\n"
		"\t\t-InALL     <str>   Input All Raw File (chr posi)\n"
		"\t\t-OutPut    <str>   The OutPut File\n"
		"\n"
		"\t\t-help              show this help\n" 
		"\n";
	return 1;
}


int parse_cmd_EX(int argc, char **argv,In3str1v * para_SV13)
{
	if (argc <=2 ) {print_Usage_Ex();return 0 ;}


	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag == "InSite")
		{
			if(i + 1 == argc) {LogLackArg(flag);return 0;}
			i++;
			para_SV13->InStr1=argv[i];
		}
		else if (flag == "InALL")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			para_SV13->InStr2=argv[i];
		}
		else if (flag == "OutPut")
		{
			if(i + 1 == argc){LogLackArg(flag); return 0;}
			i++;
			para_SV13->InStr3=argv[i];
		}
		else if (flag  == "help")
		{
			print_Usage_Ex();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((para_SV13->InStr3).empty() || (para_SV13->InStr2).empty() || (para_SV13->InStr1).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	return 1 ;
}


//int Alg_View_main(int argc, char *argv[])
//
//int main(int argc, char *argv[])
int EX_main(int argc, char *argv[])
{
	In3str1v * para_SV13 = new In3str1v;
	if (parse_cmd_EX(argc, argv, para_SV13 )==0)
	{
		delete para_SV13 ;
		return 0;
	}
	char * A = const_cast<char*>((para_SV13->InStr1).c_str());
	char * B = const_cast<char*>((para_SV13->InStr2).c_str());
	char * C = const_cast<char*>((para_SV13->InStr3).c_str()); 
	char * ssTmp[11]={"SF", "-InFile1", A ,"-InFile2" , B , "-OutPut", C , "-ID1", "1,2" , "-ID2", "1,2"};
	File_SF_main(11 , ssTmp);
	delete para_SV13 ;
	return 0;
}


#endif /* Ex_H_ */

