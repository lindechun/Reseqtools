#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstdlib>
#include <stdio.h>
#include "../include/zlib/zlib.h"
#include "../ALL/kseq.h"
#include "../ALL/comm.h"

#include "RefMatch.h"
#include "BaseModify.h"
#include "RefGetCDS.h"
#include "RefCutF.h"
#include "RefCutS.h"
#include "CDS2Pep.h"
#include "RefFindN.h"
#include "RefSubSeq.h"
#include "RefSample.h"
#include "RefSort.h"
#include "RefReform.h"
#include "RefSplit.h"
#include "RefHeader.h"
#include "ChangPosi.h"
#include "ReffindSubSeq.h"
#include "RefRegenerate.h"
#include "RefStat.h"
#include "RefFilter.h"

//KSEQ_INIT(gzFile, gzread)

using namespace std;
int FA_BaseModify_main(int argc, char *argv[]) ;
int FA_FSubSeq_main(int argc, char *argv[]);
int FA_macth_main(int argc, char *argv[]) ;
int FA_NRegion_main(int argc, char *argv[]) ;
int FA_CutFile_main(int argc, char *argv[]) ;
int FA_CutSeq_main(int argc, char *argv[]) ;
int FA_Order_main(int argc, char *argv[]) ;
int FA_stat_main(int argc, char *argv[]);
int FA_SubSeq_main(int argc, char *argv[]) ;
int FA_Filter_main(int argc, char *argv[]) ;
int FA_Regenerate_main(int argc, char *argv[]);
int FA_Reform_main(int argc, char *argv[]) ;
int FA_GetCDS_main(int argc, char *argv[]) ;
int FA_CDS2Pep_main(int argc, char *argv[]) ;
int FA_Sort_main(int argc, char *argv[]) ;
int FA_Split_main(int argc, char *argv[]) ;
int FA_SamHeader_main(int argc, char *argv[]) ;
int FA_ChangPosi_main(int argc, char *argv[]) ;
static int  FA_usage ()
{
	cerr<<""
		"\n"
		"\tFaTools Usage:\n\n"
		"\t\tstat        quick stat fasta's info\n"
		"\t\tfindN       quick find fasta's N region\n"
		"\t\tfindSubSeq  quick find fasta's one SubSeq region\n"
		"\t\textract     get fragments from seq based on coordinates\n"
		"\t\tregenerate  merge a new Ref Based scaffolds\n"
		"\t\tsplit       split InFa, each Seq one File\n"
		"\t\tfilter      filter the short & too many 'N' Seq\n"
		"\t\tcutF        cut fasta to fixed Num of subFile in total\n"
		"\t\tcutS        cut fasta to fixed Num of Seq in each subfile\n"
		"\t\tgetSP       get Seq by specified ID or pattern\n"
		"\t\tgetSN       get Seq by specified order Num range\n"
		"\t\treform      reform/modify the sequence\n"
		"\t\tsort        rank the seq By SeqID or Length\n"
		"\t\tgetCdsPep   get CDS Seq & Pep Seq based the gffFile\n"
		"\t\tCDS2Pep     Translate CDS-Seq to protein-Seq\n"
		"\t\tSamHeader   quick give out the Samheader of Fa\n"
		"\t\tBaseModify  modify the single base in seq\n"
		"\t\tChangPosi   Chang Position back to Scaffolds(regenerate)\n"
		"\n"        
		"\t\tHelp        Show this help\n"
		"\n";
	return 1;
}


int Fa_Tools_main(int argc, char *argv[])
{
	if (argc < 2) { return FA_usage(); }
	else if (strcmp(argv[1], "findN") == 0) { return FA_NRegion_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "split") == 0) { return FA_Split_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "stat") == 0) { return FA_stat_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "cutF") == 0) { return FA_CutFile_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "findSubSeq") == 0) { return FA_FSubSeq_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "cutS") == 0) { return FA_CutSeq_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "getSP") == 0) { return FA_macth_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "getSN") == 0) { return FA_Order_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "extract") == 0) { return FA_SubSeq_main(argc-1, argv+1); }
	else if (strcmp(argv[1], "filter") == 0) { return FA_Filter_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "reform") == 0) { return FA_Reform_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "regenerate") == 0) { return FA_Regenerate_main(argc-1,argv+1) ;}
	else if (strcmp(argv[1], "getCdsPep") == 0) { return FA_GetCDS_main(argc-1, argv+1) ;}
	else if (strcmp(argv[1], "CDS2Pep") == 0) { return FA_CDS2Pep_main(argc-1, argv+1); }
	else if (strcmp(argv[1], "sort") == 0) { return  FA_Sort_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "SamHeader") == 0) { return  FA_SamHeader_main(argc-1, argv+1);}
	else if (strcmp(argv[1], "BaseModify") == 0) { return FA_BaseModify_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "ChangPosi") == 0) { return FA_ChangPosi_main(argc-1, argv+1) ; }
	else if (strcmp(argv[1], "Help") == 0  || strcmp(argv[1], "help") == 0) { FA_usage(); }
	else
	{
		cerr<<"FaTools [main] unrecognized command "<<argv[1]<<endl;
		return 1;
	}
	return 0;	
}


