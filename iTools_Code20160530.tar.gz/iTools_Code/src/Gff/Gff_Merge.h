#ifndef RefGffMER_H_
#define RefGffMER_H_
#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <vector>
#include <list>
#include <map>
#include <ctime>
#include "../ALL/comm.h"
#include "../ALL/DataClass.h"
#include <cstdlib>
#include "../include/gzstream/gzstream.h"
#include "../include/zlib/zlib.h"
#include <stdio.h>
#include "../ALL/kseq.h"

using namespace std ;
typedef long long  llong ;

int  Gff_AnoMerge()
{
	cout <<""
		"\n"
		"\tUsage: ChangGff -Gff <in.gff> -Mergelist <ref.merlist> -OutPut <out.gff>\n"
		"\n"
		"\t\t-Mergelist  <str>   InPut the Mergelist (old Ref <-> new Ref)\n"
		"\t\t-Gff        <str>   InPut old Ref gff\n"
		"\t\t-OutPut     <str>   OutPut the new Ref Gff \n"
		"\n"
		"\t\t-help               show this help\n"
		"\n";
	return 1;
}


int Gff_Merge01(int argc, char **argv , In3str1v * paraFA04)
{
	if (argc <=2 ) {Gff_AnoMerge();return 0;}

	for(int i = 1; i < argc ; i++)
	{
		if(argv[i][0] != '-')
		{
			cerr << "command option error! please check." << endl;
			return 0;
		}
		string flag=argv[i] ;
		flag=replace_all(flag,"-","");

		if (flag  == "OutPut" )
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr1=argv[i];
		}
		else if (flag  ==  "Mergelist")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr2=argv[i];
		}
		else if (flag  ==  "Gff")
		{
			if(i + 1 == argc) {LogLackArg(flag); return 0;}
			i++;
			paraFA04->InStr3=argv[i];
		}
		else if (flag  == "help")
		{
			Gff_AnoMerge();return 0;
		}
		else
		{
			cerr << "UnKnow argument -"<<flag<<endl;
			return 0;
		}
	}
	if  ((paraFA04->InStr1).empty() || (paraFA04->InStr2).empty() ||  (paraFA04->InStr3).empty() )
	{
		cerr<< "lack argument for the must"<<endl ;
		return 0;
	}
	(paraFA04->InStr1)=add_Asuffix ( (paraFA04->InStr1) );
	return 1 ;
}

int Gff_Merge_main(int argc, char *argv[])
	//int main(int argc, char *argv[])
{
	In3str1v *paraFA04 = new In3str1v;
	if( Gff_Merge01(argc, argv, paraFA04 )==0)
	{
		delete  paraFA04 ;
		return 0 ;
	}

	igzstream  GFF ((paraFA04->InStr3).c_str(),ifstream::in);
	if(!GFF.good())
	{
		cerr << "open InputFile error: "<<(paraFA04->InStr3)<<endl;
		delete  paraFA04 ; return 0;
	}

	igzstream MER ((paraFA04->InStr2).c_str(),ifstream::in);
	if (MER.fail())
	{
		cerr << "open mergelist File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}


	ogzstream OUT (((paraFA04->InStr1)).c_str());

	if(OUT.fail())
	{
		cerr << "open OUT File error: "<<(paraFA04->InStr1)<<endl;
		delete  paraFA04 ; return  0;
	}

	map  <string, pair <string,llong> > MerList ;

	while(!MER.eof())
	{
		string  line ;
		getline(MER,line);
		if (line.length()<=0)  { continue  ; }
		if (line[0] == '#')   { continue  ; }
		istringstream isone (line,istringstream::in);
		string oldchr, newchr ;
		llong  o_start,o_end,n_start,n_end ; 
		isone>>oldchr>>o_start>>o_end>>newchr>>n_start>>n_end;
		pair <string,llong> chr_site ;
		chr_site=make_pair(newchr,n_start);
		//    MerList[oldchr]=chr_site;
		MerList.insert(map < string,pair <string,llong> > :: value_type(oldchr,chr_site));
	}
	MER.close();

	while(!GFF.eof())
	{
		string  line ;
		getline(GFF,line);
		if (line.length()<=0 || line[0] == '#' )  { OUT<<line<<endl; continue  ; }

		vector<string> Temp;
		split(line,Temp,"\t");
		llong Start,End ;

		istringstream isone3 (Temp[3],istringstream::in);  isone3>>Start;
		istringstream isone4 (Temp[4],istringstream::in);  isone4>>End;

		map <string,pair <string,llong> > :: iterator it ;
		it =MerList.find(Temp[0]);
		if (it!=MerList.end())
		{
			llong n_Start=Start+((it->second).second)-1;
			llong n_End=End+((it->second).second)-1;
			string n_chr=(it->second).first;
			OUT<<n_chr<<"\t"<<Temp[1]<<"\t"<<Temp[2]<<"\t"<<n_Start<<"\t"<<n_End;
			int ve_site=Temp.size();
			for (int ii=5;ii<ve_site; ii++)
			{
				OUT<<"\t"<<Temp[ii];
			}
			OUT<<endl;
		}
		else
		{
			OUT<<line<<endl;
		}
	}
	GFF.close();
	OUT.close();
	delete paraFA04 ;
	return 0;
}
#endif // RefGffAno_H_ //
///////// swimming in the sky and flying in the sea ////////////

