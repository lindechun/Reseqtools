//#include "RankSum.hh"
#ifndef rank_sum_HH_
#define rank_sum_HH_ 


double * rank_table_gen() {
	// When N <= 63, (so that n1<=31), use this table to test
	ubit64_t i, n1, N, T1;
	double p_left, p_right;

	// Calculate the factorials
	double * fact = new double [64];
	fact[0]=(double)1.0;
	for(i=1;i!=64;i++) {
		fact[i] = fact[i-1]*i;
	}

	ubit64_t * rank_sum= new ubit64_t [64*64*2048]; // 6bit: N; 6bit: n1; 11bit; T1
	memset(rank_sum, 0, sizeof(ubit64_t)*64*64*2048);
	double * p_rank= new double [64*64*2048];
	memset(rank_sum, 0, sizeof(double)*64*64*2048);
	rank_sum[0]=1;
	for(N=1;N!=64;N++) {
		//cerr<<N<<endl;
		for(n1=0;n1<=N;n1++) {
			//cerr<<n1<<endl;
			for(T1=(1+n1)*n1/2;T1<=(N+N-n1+1)*n1/2;T1++) {
				//cerr<<T1<<endl;
				// Dynamic programming to generate the table
				rank_sum[N<<17|n1<<11|T1] = rank_sum[((N-1)<<17)|(n1<<11)|T1] + ((T1>=N && n1>0) ? rank_sum[((N-1)<<17)|((n1-1)<<11)|(T1-N)]:0);
				// Here, the p_rank is not cumulative
				p_rank[(N<<17)|(n1<<11)|T1] = rank_sum[N<<17|n1<<11|T1] / (fact[N]/(fact[n1]*fact[N-n1]));
				//cerr<<p_rank[(N<<17)|(n1<<11)|T1]<<endl;
			}
			p_left = 0.0, p_right =1.0;
			for(T1=(1+n1)*n1/2;T1<=(N+N-n1+1)*n1/2;T1++) {
				p_right = 1.0 - p_left;
				p_left += p_rank[(N<<17)|(n1<<11)|T1];
				p_rank[N<<17|n1<<11|T1] = (p_left<p_right?p_left:p_right);
				//std::cerr<<N<<"\t"<<n1<<"\t"<<T1<<"\t"<<p_rank[(N<<17)|(n1<<11)|T1]<<endl;
			}
		}
	}
	delete [] rank_sum;
	delete [] fact;
	return p_rank;
}

double normal_value(double z) {
	if (z>6.0 || z<-6.0) {
		return 0.0;
	}
	else {
		double b1 = 0.31938153;
		double b2 = -0.356563782;
		double b3 = 1.781477937;
		double b4 = -1.821255978;
		double b5 = 1.330274429;
		double p = 0.2316419;
		double c2 = 0.39894228;

		double a = fabs(z);
		double t = 1.0/(1.0+a*p);
		double b = c2*exp((-z)*(z/2.0));
		double n = ((((b5*t+b4)*t+b3)*t+b2)*t+b1)*t;
		n = 1.0 - b*n;
		if (z < 0.0) n = 1.0 - n;
		return n>0.5?1-n:n;
	}
}

double normal_test(int n1, int n2, double T1, double T2) {
	double u1, u2;
	u1 = (T1 - n1*(n1+n2+1)/2) / sqrt(n1*n2*(n1+n2+1)/(double)12);
	u2 = (T2 - n2*(n1+n2+1)/2) / sqrt(n1*n2*(n1+n2+1)/(double)12);
	//cerr<<u1<<'\t'<<u2<<endl;
	return normal_value(fabs(u1)>fabs(u2)?u1:u2);
}

double table_test(double *p_rank, int n1, int n2, double T1, double T2) {
	if(n1<=n2) {
		return p_rank[(n1+n2)<<17|n1<<11|(int)(T1)]+(T1-(int)T1)*(p_rank[(n1+n2)<<16|n1<<11|(int)(T1+1)]-p_rank[(n1+n2)<<17|n1<<11|(int)(T1)]);
	}
	else {
		return p_rank[(n1+n2)<<17|n2<<11|(int)(T2)]+(T2-(int)T2)*(p_rank[(n1+n2)<<16|n2<<11|(int)(T2+1)]-p_rank[(n1+n2)<<17|n2<<11|(int)(T2)]);
	}
}

//double rank_test(Site & info, double * p_rank, int *same_qual_count, double *rank_array, char zero, ofstream & output) {
double rank_test(Site & info, double * p_rank, int *same_qual_count, double *rank_array, char zero , int RefNum , int AltNum ) {

    memset(same_qual_count,0,sizeof(int)*256);
	memset(rank_array,0,sizeof(double)*256);

	int rank(0);
	double T[4]={0.0, 0.0, 0.0, 0.0};
	int q_sum[4]={0,0,0,0} ;
        //q1(-1e6), q2(-1e6), q3(-1e6), q4(-1e6);
	int count[4]={0,0,0,0};
	bool is_need[4] ={false,false,false,false};
	is_need[RefNum]=true; is_need[AltNum]=true;
	int o_base, i;
	char q_min=0, q_max=0;
	string curr_q_base;
	for(o_base=0;o_base<4;o_base++) {
		curr_q_base = info.get_q(o_base);
        int tmpL=curr_q_base.length() ;
		for(i=0; i!=tmpL  && curr_q_base[i] != '.'; i++) {
			q_sum[o_base] += (curr_q_base[i]-zero);
			if(is_need[o_base]) {
				count[o_base]+=1;
				same_qual_count[curr_q_base[i]] += 1;
				if (curr_q_base[i]>q_max) {
					q_max = curr_q_base[i];
				}
				else if (curr_q_base[i]<q_min) {
					q_min = curr_q_base[i];
				}
				else {
					;
			}
			}
		}
        /*////
		if(is_need[o_base]) {
			if (q_sum[o_base] > q1) {
				q2 = q1;
				q1 = q_sum[o_base];
			}
			else {
				q2 = q_sum[o_base];
			}
		}
		else {
			if (q_sum[o_base] > q3) {
				q4 = q3;
				q3 = q_sum[o_base];
			}
			else {
				q4 = q_sum[o_base];
			}
		}
        ///*///
	}
	//cerr<<q1<<'\t'<<q2<<'\t'<<q3<<'\t'<<q4<<endl;
	//exit(1);
	rank = 0;
	char q_score;
	for(q_score=q_min;q_score<=q_max;q_score++) {
		rank_array[q_score]= rank+(1+same_qual_count[q_score])/2.0;
		rank += same_qual_count[q_score];
	}
	for(o_base=0;o_base<4;o_base++) {
		if(!is_need[o_base]) continue;
		curr_q_base = info.get_q(o_base);
        int tmpL=curr_q_base.length() ;
		for(i=0; i!=tmpL && curr_q_base[i] != '.'; i++) {
			T[o_base] += rank_array[curr_q_base[i]];
//cerr<<("ACTG"[o_base])<<'\t'<<curr_q_base[i]<<'\t'<<rank_array[curr_q_base[i]]<<endl;
		}
	}
	double RST_value;
	if (count[RefNum]+count[AltNum]<64) {
		RST_value =  table_test(p_rank, count[RefNum], count[AltNum], T[RefNum], T[AltNum]);
	}
	else {
		RST_value = normal_test(count[RefNum], count[AltNum], T[RefNum], T[AltNum]);
	}
//	cerr<<normal_value(1.0)<<endl;
//	output<<info.get_chr()<<'\t'<<info.get_pos()<<'\t'<<RST_value<<'\t'<<count[info.get_bin_allele2()]<<'\t'<<(q2-q3)<<endl;
	return RST_value;
}

#endif // rank_sum_HH_

